import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  email: text("email").notNull().unique(),
  createdAt: text("created_at").notNull().default("NOW()"),
});

export const watchlists = pgTable("watchlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: text("created_at").notNull().default("NOW()"),
});

export const watchlistStocks = pgTable("watchlist_stocks", {
  id: serial("id").primaryKey(),
  watchlistId: integer("watchlist_id").notNull(),
  symbol: text("symbol").notNull(),
  addedAt: text("added_at").notNull().default("NOW()"),
});

export const analyses = pgTable("analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  growthRateWeight: integer("growth_rate_weight").notNull().default(25),
  financialHealthWeight: integer("financial_health_weight").notNull().default(20),
  industryPositionWeight: integer("industry_position_weight").notNull().default(15),
  innovationWeight: integer("innovation_weight").notNull().default(15),
  communityWeight: integer("community_weight").notNull().default(10),
  esgScoreWeight: integer("esg_score_weight").notNull().default(10),
  aiSentimentWeight: integer("ai_sentiment_weight").notNull().default(5),
  createdAt: text("created_at").notNull().default("NOW()"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
});

export const insertWatchlistSchema = createInsertSchema(watchlists).pick({
  name: true,
  description: true,
});

export const insertWatchlistStockSchema = createInsertSchema(watchlistStocks).pick({
  watchlistId: true,
  symbol: true,
});

export const insertAnalysisSchema = createInsertSchema(analyses).pick({
  name: true,
  description: true,
  growthRateWeight: true,
  financialHealthWeight: true,
  industryPositionWeight: true,
  innovationWeight: true,
  communityWeight: true,
  esgScoreWeight: true,
  aiSentimentWeight: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;
export type Watchlist = typeof watchlists.$inferSelect;

export type InsertWatchlistStock = z.infer<typeof insertWatchlistStockSchema>;
export type WatchlistStock = typeof watchlistStocks.$inferSelect;

export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type Analysis = typeof analyses.$inferSelect;
