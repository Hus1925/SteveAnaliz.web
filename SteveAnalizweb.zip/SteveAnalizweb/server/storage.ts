import { users, type User, type InsertUser, watchlists, type Watchlist, type InsertWatchlist, watchlistStocks, type WatchlistStock, type InsertWatchlistStock, analyses, type Analysis, type InsertAnalysis } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getWatchlists(userId: number): Promise<Watchlist[]>;
  getWatchlist(id: number): Promise<Watchlist | undefined>;
  createWatchlist(watchlist: InsertWatchlist & { userId: number }): Promise<Watchlist>;
  deleteWatchlist(id: number): Promise<void>;
  
  getWatchlistStocks(watchlistId: number): Promise<WatchlistStock[]>;
  addStockToWatchlist(stock: InsertWatchlistStock): Promise<WatchlistStock>;
  removeStockFromWatchlist(id: number): Promise<void>;
  
  getAnalyses(userId: number): Promise<Analysis[]>;
  getAnalysis(id: number): Promise<Analysis | undefined>;
  createAnalysis(analysis: InsertAnalysis & { userId: number }): Promise<Analysis>;
  deleteAnalysis(id: number): Promise<void>;
  
  sessionStore: session.SessionStore;
}

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private watchlists: Map<number, Watchlist>;
  private watchlistStocks: Map<number, WatchlistStock>;
  private analyses: Map<number, Analysis>;
  currentId: number;
  currentWatchlistId: number;
  currentWatchlistStockId: number;
  currentAnalysisId: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.watchlists = new Map();
    this.watchlistStocks = new Map();
    this.analyses = new Map();
    this.currentId = 1;
    this.currentWatchlistId = 1;
    this.currentWatchlistStockId = 1;
    this.currentAnalysisId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    // Başlangıç kullanıcısı oluştur - basit hash için '123456' şifresi
    const defaultUser = {
      id: this.currentId++,
      username: "demo",
      password: "c80a52684f529c575174e3f558ae3db870d73840162ea8d98fd499bb1f279b2c.f33723a34ee5fbd288c0129bdd893e98", // '123456' şifresi
      email: "demo@example.com",
      name: "Demo User",
      createdAt: new Date().toISOString()
    };
    this.users.set(defaultUser.id, defaultUser);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const createdAt = new Date().toISOString();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }
  
  async getWatchlists(userId: number): Promise<Watchlist[]> {
    return Array.from(this.watchlists.values()).filter(
      (watchlist) => watchlist.userId === userId,
    );
  }
  
  async getWatchlist(id: number): Promise<Watchlist | undefined> {
    return this.watchlists.get(id);
  }
  
  async createWatchlist(watchlist: InsertWatchlist & { userId: number }): Promise<Watchlist> {
    const id = this.currentWatchlistId++;
    const createdAt = new Date().toISOString();
    const newWatchlist: Watchlist = { ...watchlist, id, createdAt };
    this.watchlists.set(id, newWatchlist);
    return newWatchlist;
  }
  
  async deleteWatchlist(id: number): Promise<void> {
    this.watchlists.delete(id);
    
    // Delete associated stocks
    const associatedStocks = Array.from(this.watchlistStocks.values())
      .filter(stock => stock.watchlistId === id);
      
    for (const stock of associatedStocks) {
      this.watchlistStocks.delete(stock.id);
    }
  }
  
  async getWatchlistStocks(watchlistId: number): Promise<WatchlistStock[]> {
    return Array.from(this.watchlistStocks.values()).filter(
      (stock) => stock.watchlistId === watchlistId,
    );
  }
  
  async addStockToWatchlist(stock: InsertWatchlistStock): Promise<WatchlistStock> {
    const id = this.currentWatchlistStockId++;
    const addedAt = new Date().toISOString();
    const newStock: WatchlistStock = { ...stock, id, addedAt };
    this.watchlistStocks.set(id, newStock);
    return newStock;
  }
  
  async removeStockFromWatchlist(id: number): Promise<void> {
    this.watchlistStocks.delete(id);
  }
  
  async getAnalyses(userId: number): Promise<Analysis[]> {
    return Array.from(this.analyses.values()).filter(
      (analysis) => analysis.userId === userId,
    );
  }
  
  async getAnalysis(id: number): Promise<Analysis | undefined> {
    return this.analyses.get(id);
  }
  
  async createAnalysis(analysis: InsertAnalysis & { userId: number }): Promise<Analysis> {
    const id = this.currentAnalysisId++;
    const createdAt = new Date().toISOString();
    const newAnalysis: Analysis = { ...analysis, id, createdAt };
    this.analyses.set(id, newAnalysis);
    return newAnalysis;
  }
  
  async deleteAnalysis(id: number): Promise<void> {
    this.analyses.delete(id);
  }
}

export const storage = new MemStorage();
