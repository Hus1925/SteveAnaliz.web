import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertWatchlistSchema, insertWatchlistStockSchema, insertAnalysisSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Watchlist routes
  app.get("/api/watchlists", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const watchlists = await storage.getWatchlists(req.user.id);
    res.json(watchlists);
  });

  app.post("/api/watchlists", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const watchlist = insertWatchlistSchema.parse(req.body);
      const newWatchlist = await storage.createWatchlist({
        ...watchlist,
        userId: req.user.id,
      });
      res.status(201).json(newWatchlist);
    } catch (err) {
      res.status(400).json({ error: "Invalid watchlist data" });
    }
  });

  app.get("/api/watchlists/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const watchlist = await storage.getWatchlist(parseInt(req.params.id));
    if (!watchlist) {
      return res.status(404).json({ error: "Watchlist not found" });
    }
    
    if (watchlist.userId !== req.user.id) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    res.json(watchlist);
  });

  app.delete("/api/watchlists/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const watchlist = await storage.getWatchlist(parseInt(req.params.id));
    if (!watchlist) {
      return res.status(404).json({ error: "Watchlist not found" });
    }
    
    if (watchlist.userId !== req.user.id) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    await storage.deleteWatchlist(parseInt(req.params.id));
    res.sendStatus(204);
  });

  // Watchlist stocks routes
  app.get("/api/watchlists/:id/stocks", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const watchlist = await storage.getWatchlist(parseInt(req.params.id));
    if (!watchlist) {
      return res.status(404).json({ error: "Watchlist not found" });
    }
    
    if (watchlist.userId !== req.user.id) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    const stocks = await storage.getWatchlistStocks(parseInt(req.params.id));
    res.json(stocks);
  });

  app.post("/api/watchlists/:id/stocks", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const watchlist = await storage.getWatchlist(parseInt(req.params.id));
    if (!watchlist) {
      return res.status(404).json({ error: "Watchlist not found" });
    }
    
    if (watchlist.userId !== req.user.id) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    try {
      const stockData = {
        ...req.body,
        watchlistId: parseInt(req.params.id),
      };
      const validatedStock = insertWatchlistStockSchema.parse(stockData);
      const newStock = await storage.addStockToWatchlist(validatedStock);
      res.status(201).json(newStock);
    } catch (err) {
      res.status(400).json({ error: "Invalid stock data" });
    }
  });

  app.delete("/api/watchliststocks/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    await storage.removeStockFromWatchlist(parseInt(req.params.id));
    res.sendStatus(204);
  });

  // Analysis routes
  app.get("/api/analyses", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const analyses = await storage.getAnalyses(req.user.id);
    res.json(analyses);
  });

  app.post("/api/analyses", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const analysis = insertAnalysisSchema.parse(req.body);
      const newAnalysis = await storage.createAnalysis({
        ...analysis,
        userId: req.user.id,
      });
      res.status(201).json(newAnalysis);
    } catch (err) {
      res.status(400).json({ error: "Invalid analysis data" });
    }
  });

  app.get("/api/analyses/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const analysis = await storage.getAnalysis(parseInt(req.params.id));
    if (!analysis) {
      return res.status(404).json({ error: "Analysis not found" });
    }
    
    if (analysis.userId !== req.user.id) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    res.json(analysis);
  });

  app.delete("/api/analyses/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const analysis = await storage.getAnalysis(parseInt(req.params.id));
    if (!analysis) {
      return res.status(404).json({ error: "Analysis not found" });
    }
    
    if (analysis.userId !== req.user.id) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    await storage.deleteAnalysis(parseInt(req.params.id));
    res.sendStatus(204);
  });

  const httpServer = createServer(app);

  return httpServer;
}
