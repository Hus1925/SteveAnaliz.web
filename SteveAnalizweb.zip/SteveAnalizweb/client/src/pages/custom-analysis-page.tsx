import { useState, useEffect, useRef } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { DashboardHeader } from "@/components/dashboard-header";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { InteractiveSlider } from "@/components/ui/interactive-slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs-new";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  CheckCircle, 
  Filter, 
  Search, 
  Sliders, 
  XCircle, 
  BarChart4, 
  Gauge,
  Settings,
  SlidersHorizontal,
  PieChart,
  TrendingUp,
  EyeOff,
  Eye,
  Info
} from "lucide-react";
import { availableCriteria, categoryLabels, SelectedCriterion, calculateAnalysisScore } from "@/lib/data/analysis-criteria";
import { topStocks, criteria } from "@/lib/data/mock-data";
import { preselectedStocks } from "@/lib/data/extended-market-data";
import { formatCurrency, formatPercentage, getScoreColor, cn } from "@/lib/utils";

export default function CustomAnalysisPage() {
  // State for selected criteria
  const [selectedCriteria, setSelectedCriteria] = useState<SelectedCriterion[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>("financial");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [analysisResults, setAnalysisResults] = useState<any[]>([]);
  const [isAnalysisComplete, setIsAnalysisComplete] = useState<boolean>(false);

  // Initialize with some default criteria
  useEffect(() => {
    const initialCriteria = availableCriteria
      .filter(criterion => 
        criterion.category === 'financial' && 
        ['eps', 'pe_ratio', 'revenue_growth', 'profit_margin'].includes(criterion.id)
      )
      .map(criterion => ({
        ...criterion,
        weight: criterion.defaultWeight,
        enabled: true
      }));
    
    setSelectedCriteria(initialCriteria);
  }, []);

  // Filter criteria by search term and active category
  const filteredCriteria = availableCriteria.filter(criterion => 
    (activeCategory === "all" || criterion.category === activeCategory) &&
    (criterion.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     criterion.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Check if a criterion is already selected
  const isCriterionSelected = (id: string) => {
    return selectedCriteria.some(criterion => criterion.id === id);
  };

  // Add a criterion to selected list
  const addCriterion = (criterion: typeof availableCriteria[0]) => {
    if (!isCriterionSelected(criterion.id)) {
      setSelectedCriteria([...selectedCriteria, {
        ...criterion,
        weight: criterion.defaultWeight,
        enabled: true
      }]);
    }
  };

  // Remove a criterion from selected list
  const removeCriterion = (id: string) => {
    setSelectedCriteria(selectedCriteria.filter(criterion => criterion.id !== id));
  };

  // Toggle a criterion enabled/disabled state
  const toggleCriterion = (id: string) => {
    setSelectedCriteria(selectedCriteria.map(criterion => 
      criterion.id === id ? { ...criterion, enabled: !criterion.enabled } : criterion
    ));
  };

  // Update criterion weight
  const updateCriterionWeight = (id: string, weight: number) => {
    setSelectedCriteria(selectedCriteria.map(criterion => 
      criterion.id === id ? { ...criterion, weight } : criterion
    ));
  };

  // Run analysis with selected criteria
  const runAnalysis = () => {
    // For demo purposes, we'll calculate scores using the mock data
    // In a real application, this would be replaced with API calls to get actual data
    const results = topStocks.map(stock => {
      // Simulate scores for each criterion between 0-100
      const stockData: Record<string, number> = {};
      selectedCriteria.forEach(criterion => {
        // In a real app, these would be the actual values from financial data
        stockData[criterion.id] = Math.floor(Math.random() * 100);
      });
      
      const score = calculateAnalysisScore(stockData, selectedCriteria);
      
      return {
        ...stock,
        analysisScore: score,
        criteriaValues: stockData
      };
    });
    
    // Sort by score
    results.sort((a, b) => b.analysisScore - a.analysisScore);
    
    setAnalysisResults(results);
    setIsAnalysisComplete(true);
  };

  // Reset analysis
  const resetAnalysis = () => {
    setIsAnalysisComplete(false);
    setAnalysisResults([]);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
      <Header />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="bg-primary-50 dark:bg-primary-950/40 rounded-xl p-6 mb-8 relative overflow-hidden shadow-lg">
            <div className="absolute inset-0 bg-gradient-to-br from-primary-100/50 to-transparent dark:from-primary-900/20"></div>
            
            <div className="relative z-10">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-primary-400 bg-clip-text text-transparent dark:from-primary-400 dark:to-primary-200">
                    Özel Analiz
                  </h1>
                  <h2 className="text-lg font-bold text-primary-700 dark:text-primary-400 mb-1">
                    S.A.M
                  </h2>
                  <p className="text-gray-600 dark:text-gray-300 max-w-xl">
                    100+ finansal göstergeyi kullanarak kendi analiz sisteminizi oluşturun ve seçtiğiniz kriterlere göre hisseleri değerlendirin.
                  </p>
                </div>
                <div className="flex space-x-2 items-center">
                  <Badge variant="outline" className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                    <PieChart className="h-4 w-4 mr-2 text-primary-600" />
                    Kriter: {selectedCriteria.length}
                  </Badge>
                  <Badge variant="outline" className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                    <Gauge className="h-4 w-4 mr-2 text-orange-500" />
                    Ağırlık: {selectedCriteria.reduce((sum, c) => sum + c.weight, 0)}
                  </Badge>
                  <Button 
                    size="sm" 
                    onClick={() => {
                      runAnalysis();
                      alert("Analiz işlemi başladı. Sonuçlar hazırlanıyor...");
                    }}
                    disabled={selectedCriteria.filter(c => c.enabled).length === 0}
                    className="bg-gradient-to-r from-primary-600 to-primary-500 hover:from-primary-500 hover:to-primary-400 text-white shadow-md"
                  >
                    <BarChart4 className="h-4 w-4 mr-2" />
                    Analiz Et
                  </Button>
                  <div 
                    className="tooltip-container mt-2 text-xs font-semibold text-primary-700 dark:text-primary-400 cursor-help ml-1"
                    title="SteveAnaliz.web Modülü"
                  >
                    S.A.M
                    <span className="tooltip-text">SteveAnaliz.web Modülü</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-6 gap-4">
                <div className="col-span-6 md:col-span-4">
                  <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-lg shadow-sm p-3">
                    <div className="flex space-x-2 mb-4">
                      <Input
                        placeholder="100+ kriter arasında arama yapın..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="flex-grow bg-transparent border-gray-200 dark:border-gray-700"
                      />
                      <Button variant="outline" size="icon" onClick={() => setSearchTerm("")}>
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <Tabs 
                      defaultValue="financial" 
                      value={activeCategory}
                      onValueChange={setActiveCategory}
                      className="w-full"
                    >
                      <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-1 mb-4">
                        <TabsList className="grid grid-cols-6 mb-1 bg-transparent">
                          <TabsTrigger value="financial" className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800">
                            <TrendingUp className="h-4 w-4 mr-1 text-blue-500" />
                            <span className="hidden sm:inline">Finansal</span>
                          </TabsTrigger>
                          <TabsTrigger value="technical" className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800">
                            <BarChart4 className="h-4 w-4 mr-1 text-purple-500" />
                            <span className="hidden sm:inline">Teknik</span>
                          </TabsTrigger>
                          <TabsTrigger value="fundamental" className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800">
                            <SlidersHorizontal className="h-4 w-4 mr-1 text-green-500" />
                            <span className="hidden sm:inline">Temel</span>
                          </TabsTrigger>
                          <TabsTrigger value="esg" className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800">
                            <Gauge className="h-4 w-4 mr-1 text-orange-500" />
                            <span className="hidden sm:inline">ESG</span>
                          </TabsTrigger>
                          <TabsTrigger value="sentiment" className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800">
                            <Settings className="h-4 w-4 mr-1 text-yellow-500" />
                            <span className="hidden sm:inline">Duyarlılık</span>
                          </TabsTrigger>
                          <TabsTrigger value="ai" className="data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800">
                            <PieChart className="h-4 w-4 mr-1 text-red-500" />
                            <span className="hidden sm:inline">YZ</span>
                          </TabsTrigger>
                        </TabsList>
                        <TabsTrigger 
                          value="all" 
                          className="w-full data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800"
                        >
                          Tüm Kriterler ({availableCriteria.length})
                        </TabsTrigger>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[400px] overflow-y-auto pr-1">
                        {filteredCriteria.map((criterion) => (
                          <div
                            key={criterion.id}
                            className={cn(
                              "relative p-3 border rounded-lg transition-all",
                              "hover:shadow-md hover:border-primary/40",
                              "bg-white dark:bg-gray-800",
                              isCriterionSelected(criterion.id) 
                                ? "ring-1 ring-primary border-primary/20" 
                                : "border-gray-200 dark:border-gray-700"
                            )}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-medium text-sm flex items-center">
                                  {categoryLabels[criterion.category as keyof typeof categoryLabels] === "Finansal" && 
                                    <TrendingUp className="h-3 w-3 mr-1 text-blue-500" />}
                                  {categoryLabels[criterion.category as keyof typeof categoryLabels] === "Teknik" && 
                                    <BarChart4 className="h-3 w-3 mr-1 text-purple-500" />}
                                  {categoryLabels[criterion.category as keyof typeof categoryLabels] === "Temel" && 
                                    <SlidersHorizontal className="h-3 w-3 mr-1 text-green-500" />}
                                  {categoryLabels[criterion.category as keyof typeof categoryLabels] === "ESG" && 
                                    <Gauge className="h-3 w-3 mr-1 text-orange-500" />}
                                  {categoryLabels[criterion.category as keyof typeof categoryLabels] === "Duyarlılık" && 
                                    <Settings className="h-3 w-3 mr-1 text-yellow-500" />}
                                  {categoryLabels[criterion.category as keyof typeof categoryLabels] === "Yapay Zeka" && 
                                    <PieChart className="h-3 w-3 mr-1 text-red-500" />}
                                  {criterion.name}
                                </h4>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                                  {criterion.description}
                                </p>
                              </div>
                              <Button
                                variant={isCriterionSelected(criterion.id) ? "destructive" : "secondary"}
                                size="sm"
                                className={cn(
                                  "ml-2 h-7 px-2",
                                  isCriterionSelected(criterion.id) 
                                    ? "opacity-80 hover:opacity-100" 
                                    : "bg-primary-50 text-primary-700 hover:bg-primary-100 dark:bg-primary-900/30 dark:text-primary-200 dark:hover:bg-primary-900/50"
                                )}
                                onClick={() => isCriterionSelected(criterion.id) 
                                  ? removeCriterion(criterion.id) 
                                  : addCriterion(criterion)
                                }
                              >
                                {isCriterionSelected(criterion.id) ? "Kaldır" : "Ekle"}
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </Tabs>
                  </div>
                </div>
                
                {/* Seçili kriterler paneli */}
                <div className="col-span-6 md:col-span-2">
                  <Card className="shadow-md border-0 overflow-hidden bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm">
                    <CardHeader className="bg-primary-50/50 dark:bg-primary-900/20 border-b border-primary-100 dark:border-primary-900">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-lg">Seçilen Kriterler</CardTitle>
                        <Badge variant="outline" className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                          {selectedCriteria.length} / {availableCriteria.length}
                        </Badge>
                      </div>
                      <CardDescription>
                        Dokunmatik kaydırıcılar ile ağırlıkları ayarlayın
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {selectedCriteria.length === 0 ? (
                        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                          <p>Henüz kriter seçilmedi. Analiz için en az bir kriter ekleyin.</p>
                        </div>
                      ) : (
                        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                          {selectedCriteria.map((criterion) => (
                            <div 
                              key={criterion.id} 
                              className={cn(
                                "p-3 border rounded-lg relative transition-colors",
                                criterion.enabled 
                                  ? "border-primary-500/30 bg-primary-50/50 dark:bg-primary-900/20 shadow-sm" 
                                  : "border-gray-200 bg-gray-50 dark:border-gray-700 dark:bg-gray-800/50 opacity-70"
                              )}
                            >
                              <div className="flex justify-between items-center mb-2">
                                <div className="flex items-center">
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    className={cn(
                                      "p-0 h-7 mr-2",
                                      criterion.enabled ? "text-primary" : "text-gray-400"
                                    )}
                                    onClick={() => toggleCriterion(criterion.id)}
                                  >
                                    {criterion.enabled ? (
                                      <Eye className="h-4 w-4" />
                                    ) : (
                                      <EyeOff className="h-4 w-4" />
                                    )}
                                  </Button>
                                  <div>
                                    <h4 className="font-medium text-sm">{criterion.name}</h4>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">
                                      {categoryLabels[criterion.category as keyof typeof categoryLabels]}
                                    </p>
                                  </div>
                                </div>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  onClick={() => removeCriterion(criterion.id)}
                                  className="h-7 w-7 p-0"
                                >
                                  <XCircle className="h-4 w-4" />
                                </Button>
                              </div>
                              
                              <div className="mt-2">
                                <div className="flex justify-between items-center mb-1">
                                  <span className="text-xs font-medium">Ağırlık: {criterion.weight}</span>
                                  <Badge variant="outline" className={cn(
                                    "text-xs h-5 px-2",
                                    criterion.weight < 30 ? "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300" : 
                                    criterion.weight < 70 ? "bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300" : 
                                    "bg-primary-50 text-primary-700 dark:bg-primary-950 dark:text-primary-300"
                                  )}>
                                    {criterion.weight < 30 ? "Düşük" : criterion.weight < 70 ? "Orta" : "Yüksek"}
                                  </Badge>
                                </div>
                                <InteractiveSlider
                                  value={criterion.weight}
                                  min={5}
                                  max={100}
                                  step={5}
                                  onChange={(value) => updateCriterionWeight(criterion.id, value)}
                                  disabled={!criterion.enabled}
                                  className={`${!criterion.enabled && "opacity-50"}`}
                                  showValueBubble={true}
                                  showMarks={true}
                                  marksCount={5}
                                  touchFeedback={true}
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="flex justify-between border-t p-4">
                      <div className="flex space-x-2">
                        <Badge variant="outline" className="h-7 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                          {selectedCriteria.length} kriter seçildi
                        </Badge>
                        <Badge variant="outline" className="h-7 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                          {selectedCriteria.filter(c => c.enabled).length} aktif
                        </Badge>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={resetAnalysis}
                          disabled={!isAnalysisComplete}
                        >
                          <Filter className="h-4 w-4 mr-2" />
                          Temizle
                        </Button>
                        <Button 
                          size="sm"
                          onClick={runAnalysis}
                          disabled={selectedCriteria.filter(c => c.enabled).length === 0}
                          className="bg-gradient-to-r from-primary-600 to-primary-500 hover:from-primary-500 hover:to-primary-400"
                        >
                          <Sliders className="h-4 w-4 mr-2" />
                          Analiz Et
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                </div>
              </div>
            </div>
          </div>

          {/* Analiz sonuçları */}
          {isAnalysisComplete && (
            <Card className="mb-6">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Analiz Sonuçları</CardTitle>
                    <CardDescription>
                      Seçtiğiniz kriterlere göre stokların analiz sonuçları
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="h-7 bg-white/80 dark:bg-gray-800/80">
                      <BarChart4 className="h-4 w-4 mr-1 text-primary-600" />
                      {analysisResults.length} Hisse Değerlendirildi
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader className="bg-gray-50 dark:bg-gray-900/50">
                      <TableRow>
                        <TableHead>Sembol</TableHead>
                        <TableHead>Şirket</TableHead>
                        <TableHead>Borsa</TableHead>
                        <TableHead className="text-right">Fiyat</TableHead>
                        <TableHead className="text-right">Değişim</TableHead>
                        <TableHead className="text-center">Analiz Puanı</TableHead>
                        <TableHead>Tavsiye</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {analysisResults.map((stock) => (
                        <TableRow key={stock.id} className="hover:bg-gray-50 dark:hover:bg-gray-900/30">
                          <TableCell className="font-medium">{stock.symbol}</TableCell>
                          <TableCell>{stock.name}</TableCell>
                          <TableCell>{stock.exchange}</TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(stock.price, "USD")}
                          </TableCell>
                          <TableCell className={`text-right ${stock.changePercent >= 0 ? "text-green-600" : "text-red-600"}`}>
                            {formatPercentage(stock.changePercent)}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge className={`${getScoreColor(stock.analysisScore)}`}>
                              {stock.analysisScore.toFixed(1)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={`${
                              stock.analysisScore >= 70 ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300" :
                              stock.analysisScore >= 50 ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300" :
                              "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
                            }`}>
                              {stock.analysisScore >= 70 ? "Al" :
                               stock.analysisScore >= 50 ? "Tut" : "Sat"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
          
          {/* Detaylı kriter bazlı sonuçlar */}
          {isAnalysisComplete && analysisResults.length > 0 && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Kriter Bazlı Analiz</CardTitle>
                <CardDescription>
                  Seçili hisselerin her kriter için aldığı puanlar
                </CardDescription>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Hisse</TableHead>
                      {selectedCriteria.filter(c => c.enabled).map(criterion => (
                        <TableHead key={criterion.id} title={criterion.description}>
                          {criterion.name}
                        </TableHead>
                      ))}
                      <TableHead className="text-right">Toplam Puan</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {analysisResults.slice(0, 5).map((stock) => (
                      <TableRow key={stock.id}>
                        <TableCell className="font-medium">{stock.symbol}</TableCell>
                        {selectedCriteria.filter(c => c.enabled).map(criterion => (
                          <TableCell key={criterion.id}>
                            <div className="flex items-center">
                              <div className="w-full bg-gray-200 rounded-full h-2 mr-2 dark:bg-gray-700">
                                <div 
                                  className="bg-primary h-2 rounded-full" 
                                  style={{ width: `${stock.criteriaValues[criterion.id]}%` }}
                                ></div>
                              </div>
                              <span className="text-xs">{stock.criteriaValues[criterion.id]}</span>
                            </div>
                          </TableCell>
                        ))}
                        <TableCell className="text-right font-medium">
                          {stock.analysisScore.toFixed(1)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}