import { useEffect, useState } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { DashboardHeader } from "@/components/dashboard-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs-new";
import { StockTable } from "@/components/stock-table";
import { PlusCircle, RefreshCw, Save } from "lucide-react";
import { topStocks } from "@/lib/data/mock-data";

export default function AnalysisPage() {
  // Analysis criteria and their default weights
  const [criteria, setCriteria] = useState([
    { id: 'growthRate', name: 'Growth Rate', weight: 25 },
    { id: 'financialHealth', name: 'Financial Health', weight: 20 },
    { id: 'industryPosition', name: 'Industry Position', weight: 15 },
    { id: 'innovation', name: 'Innovation', weight: 15 },
    { id: 'community', name: 'Community', weight: 10 },
    { id: 'esgScore', name: 'ESG Score', weight: 10 },
    { id: 'aiSentiment', name: 'AI Sentiment', weight: 5 },
  ]);

  // Track total weights to ensure they sum to 100
  const [totalWeight, setTotalWeight] = useState(100);
  const [analysisName, setAnalysisName] = useState('New Custom Analysis');
  const [analysisDescription, setAnalysisDescription] = useState('');

  // Update total weight when criteria weights change
  useEffect(() => {
    const sum = criteria.reduce((total, criterion) => total + criterion.weight, 0);
    setTotalWeight(sum);
  }, [criteria]);

  // Handle weight change for a criterion
  const handleWeightChange = (id: string, newWeight: number) => {
    setCriteria(criteria.map(c => 
      c.id === id ? { ...c, weight: newWeight } : c
    ));
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <DashboardHeader 
            title="Custom Analysis" 
            description="Customize the 7-criteria weights to match your investment strategy"
          />
          
          <Tabs defaultValue="customize">
            <TabsList className="mb-6">
              <TabsTrigger value="customize">Customize Analysis</TabsTrigger>
              <TabsTrigger value="results">Analysis Results</TabsTrigger>
              <TabsTrigger value="saved">Saved Analyses</TabsTrigger>
            </TabsList>
            
            <TabsContent value="customize">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Criteria Weights</CardTitle>
                      <CardDescription>
                        Adjust the weights of each criterion to customize your analysis. Total weight must equal 100%.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {criteria.map((criterion) => (
                          <div key={criterion.id} className="space-y-2">
                            <div className="flex justify-between">
                              <Label htmlFor={criterion.id}>{criterion.name}</Label>
                              <span className={totalWeight > 100 ? 'text-red-500' : 'text-gray-500'}>
                                {criterion.weight}%
                              </span>
                            </div>
                            <Slider
                              id={criterion.id}
                              min={0}
                              max={100}
                              step={1}
                              value={[criterion.weight]}
                              onValueChange={(values) => handleWeightChange(criterion.id, values[0])}
                            />
                          </div>
                        ))}
                        
                        <div className={`mt-4 flex justify-between font-medium ${
                          totalWeight !== 100 ? 'text-red-500' : 'text-green-600'
                        }`}>
                          <span>Total Weight:</span>
                          <span>{totalWeight}%</span>
                        </div>
                        
                        {totalWeight !== 100 && (
                          <div className="text-red-500 text-sm mt-2">
                            Total weight must equal 100%. Please adjust the weights accordingly.
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Analysis Settings</CardTitle>
                      <CardDescription>
                        Save your custom analysis for future use
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="analysis-name">Analysis Name</Label>
                          <Input 
                            id="analysis-name" 
                            value={analysisName}
                            onChange={(e) => setAnalysisName(e.target.value)}
                            placeholder="Enter a name for your analysis"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="analysis-description">Description (Optional)</Label>
                          <Input 
                            id="analysis-description" 
                            value={analysisDescription}
                            onChange={(e) => setAnalysisDescription(e.target.value)}
                            placeholder="Enter a description"
                          />
                        </div>
                        
                        <div className="pt-4 space-y-2">
                          <Button 
                            className="w-full" 
                            disabled={totalWeight !== 100}
                          >
                            <RefreshCw className="mr-2 h-4 w-4" /> Run Analysis
                          </Button>
                          
                          <Button variant="outline" className="w-full">
                            <Save className="mr-2 h-4 w-4" /> Save Analysis
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="results">
              <StockTable 
                stocks={topStocks} 
                title="Analysis Results" 
                description="Top stocks based on your custom criteria weights"
              />
            </TabsContent>
            
            <TabsContent value="saved">
              <div className="bg-white shadow rounded-lg overflow-hidden">
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200 flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-medium leading-6 text-gray-900">Saved Analyses</h3>
                    <p className="mt-1 max-w-2xl text-sm text-gray-500">Your custom analysis configurations</p>
                  </div>
                  <Button>
                    <PlusCircle className="mr-2 h-4 w-4" /> New Analysis
                  </Button>
                </div>
                <div className="p-4 divide-y divide-gray-200">
                  <div className="flex items-center justify-between py-4">
                    <div>
                      <h4 className="font-medium text-gray-900">Growth Focus</h4>
                      <p className="text-sm text-gray-500">Prioritizes growth rate and innovation</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          Growth: 35%
                        </span>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Innovation: 25%
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">Edit</Button>
                      <Button variant="outline" size="sm">Run</Button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between py-4">
                    <div>
                      <h4 className="font-medium text-gray-900">ESG Focus</h4>
                      <p className="text-sm text-gray-500">Prioritizes ESG score and community</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          ESG: 30%
                        </span>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Community: 25%
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">Edit</Button>
                      <Button variant="outline" size="sm">Run</Button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
