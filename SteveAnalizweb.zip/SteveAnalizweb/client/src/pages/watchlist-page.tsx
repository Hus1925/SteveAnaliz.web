import { useState } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { DashboardHeader } from "@/components/dashboard-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs-new";
import { StockCard } from "@/components/ui/stock-card";
import { Edit, MoreHorizontal, Plus, Search, Trash2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function WatchlistPage() {
  const [newWatchlistName, setNewWatchlistName] = useState("");
  const [newWatchlistDescription, setNewWatchlistDescription] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeWatchlist, setActiveWatchlist] = useState("all");

  // Mock watchlists
  const watchlists = [
    { id: "all", name: "All Stocks", description: "All tracked stocks", stockCount: 12 },
    { id: "tech", name: "Tech Leaders", description: "Top technology companies", stockCount: 5 },
    { id: "growth", name: "Growth Potential", description: "High growth potential stocks", stockCount: 4 },
    { id: "dividend", name: "Dividend Stocks", description: "Stocks with consistent dividends", stockCount: 3 },
  ];

  // Mock stocks
  const stocks = [
    { id: "TSLA", symbol: "TSLA", name: "Tesla Inc.", price: 824.40, change: 26.32, changePercentage: 3.3 },
    { id: "AAPL", symbol: "AAPL", name: "Apple Inc.", price: 176.28, change: -1.42, changePercentage: -0.8 },
    { id: "MSFT", symbol: "MSFT", name: "Microsoft Corp.", price: 326.80, change: -0.65, changePercentage: -0.2 },
    { id: "NVDA", symbol: "NVDA", name: "NVIDIA Corp.", price: 267.58, change: 7.49, changePercentage: 2.8 },
    { id: "META", symbol: "META", name: "Meta Platforms", price: 352.92, change: 5.22, changePercentage: 1.5 },
  ];

  const createWatchlist = () => {
    // Implementation would go here
    setIsDialogOpen(false);
    setNewWatchlistName("");
    setNewWatchlistDescription("");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center mb-6">
            <DashboardHeader 
              title="Watchlists" 
              description="Track and monitor your favorite stocks"
            />
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" /> Create Watchlist
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Watchlist</DialogTitle>
                  <DialogDescription>
                    Create a new watchlist to track your favorite stocks.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Watchlist Name</Label>
                    <Input 
                      id="name" 
                      value={newWatchlistName}
                      onChange={(e) => setNewWatchlistName(e.target.value)}
                      placeholder="Enter watchlist name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Input 
                      id="description" 
                      value={newWatchlistDescription}
                      onChange={(e) => setNewWatchlistDescription(e.target.value)}
                      placeholder="Enter description"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createWatchlist}>
                    Create
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Your Watchlists</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="px-4 py-3">
                    <div className="relative">
                      <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input 
                        placeholder="Search watchlists..." 
                        className="pl-8"
                      />
                    </div>
                  </div>
                  <div className="divide-y divide-gray-100">
                    {watchlists.map((watchlist) => (
                      <div 
                        key={watchlist.id}
                        className={`flex items-center justify-between px-4 py-3 hover:bg-gray-50 cursor-pointer ${
                          activeWatchlist === watchlist.id ? 'bg-primary-50 border-l-4 border-primary-600' : ''
                        }`}
                        onClick={() => setActiveWatchlist(watchlist.id)}
                      >
                        <div>
                          <h4 className="font-medium text-gray-900">{watchlist.name}</h4>
                          <p className="text-xs text-gray-500">{watchlist.stockCount} stocks</p>
                        </div>
                        {watchlist.id !== "all" && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:col-span-3">
              <Card>
                <CardHeader className="border-b border-gray-200">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>
                        {watchlists.find(w => w.id === activeWatchlist)?.name || "All Stocks"}
                      </CardTitle>
                      <CardDescription>
                        {watchlists.find(w => w.id === activeWatchlist)?.description || "All tracked stocks"}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input 
                          placeholder="Search stocks..." 
                          className="pl-8 w-60"
                        />
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline">
                            <Plus className="mr-2 h-4 w-4" /> Add Stock
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Add Stock to Watchlist</DialogTitle>
                            <DialogDescription>
                              Search for a stock to add to your watchlist.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="relative">
                              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                              <Input 
                                placeholder="Search by symbol or company name..." 
                                className="pl-8"
                              />
                            </div>
                            <div className="h-60 overflow-y-auto border rounded-md p-2">
                              {/* Search results would go here */}
                              <div className="text-center text-gray-500 py-10">
                                Search for stocks to add to your watchlist
                              </div>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button variant="outline">
                              Cancel
                            </Button>
                            <Button>
                              Add Selected
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <Tabs defaultValue="cards">
                    <div className="flex justify-between items-center mb-4">
                      <TabsList>
                        <TabsTrigger value="cards">Cards</TabsTrigger>
                        <TabsTrigger value="table">Table</TabsTrigger>
                      </TabsList>
                    </div>
                    
                    <TabsContent value="cards">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {stocks.map((stock) => (
                          <StockCard
                            key={stock.id}
                            symbol={stock.symbol}
                            name={stock.name}
                            price={stock.price}
                            change={stock.change}
                            changePercentage={stock.changePercentage}
                          />
                        ))}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="table">
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Symbol</TableHead>
                              <TableHead>Name</TableHead>
                              <TableHead>Price</TableHead>
                              <TableHead>Change</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {stocks.map((stock) => (
                              <TableRow key={stock.id}>
                                <TableCell className="font-medium">{stock.symbol}</TableCell>
                                <TableCell>{stock.name}</TableCell>
                                <TableCell>${stock.price.toFixed(2)}</TableCell>
                                <TableCell className={stock.change >= 0 ? "text-green-600" : "text-red-500"}>
                                  {stock.change >= 0 ? "+" : ""}{stock.change.toFixed(2)} ({stock.change >= 0 ? "+" : ""}{stock.changePercentage.toFixed(2)}%)
                                </TableCell>
                                <TableCell>
                                  <Button variant="ghost" size="sm">View Analysis</Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
