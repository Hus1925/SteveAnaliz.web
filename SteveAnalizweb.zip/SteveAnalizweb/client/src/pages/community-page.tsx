import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { DashboardHeader } from "@/components/dashboard-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, MessageSquare, Heart, TrendingUp, Share2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

// Örnek kullanıcı verileri
const sampleUsers = [
  { id: 1, name: "Ahmet Yılmaz", avatar: null, username: "ahmet_investor", followers: 352, posts: 89 },
  { id: 2, name: "Ayşe Kaya", avatar: null, username: "ayse_trader", followers: 523, posts: 124 },
  { id: 3, name: "Mehmet Demir", avatar: null, username: "mehmet_stocks", followers: 287, posts: 67 },
  { id: 4, name: "Zeynep Aydın", avatar: null, username: "zeynep_fintech", followers: 492, posts: 143 },
  { id: 5, name: "Ömer Şahin", avatar: null, username: "omer_analyst", followers: 671, posts: 205 },
];

// Örnek gönderiler
const samplePosts = [
  {
    id: 1,
    userId: 2,
    username: "ayse_trader",
    name: "Ayşe Kaya",
    content: "Bugün THYAO hisselerindeki hareketlilik dikkat çekici. Teknik analize göre kısa vadede yükseliş trendi görebiliriz.",
    likes: 48,
    comments: 12,
    shares: 5,
    timestamp: "3 saat önce",
    avatar: null,
  },
  {
    id: 2,
    userId: 5,
    username: "omer_analyst",
    name: "Ömer Şahin",
    content: "Savunma sanayii hisseleri son 3 ayda ortalama %15 değer kazandı. Sektördeki yeni gelişmeler ve ihracat rakamları bu trendin devam edebileceğini gösteriyor.",
    likes: 79,
    comments: 23,
    shares: 14,
    timestamp: "5 saat önce",
    avatar: null,
  },
  {
    id: 3,
    userId: 1,
    username: "ahmet_investor",
    name: "Ahmet Yılmaz",
    content: "Global ekonomideki durgunluk endişeleri, uzun vadeli yatırım stratejilerimizi nasıl etkilemeli? Portföy çeşitlendirmesi konusunda görüşlerinizi merak ediyorum.",
    likes: 35,
    comments: 27,
    shares: 8,
    timestamp: "Dün",
    avatar: null,
  },
  {
    id: 4,
    userId: 4,
    username: "zeynep_fintech",
    name: "Zeynep Aydın",
    content: "Teknoloji hisselerinde bugün yaşanan düşüş sadece geçici bir düzeltme mi yoksa daha uzun süreli bir trend mi başlıyor? 2024 için teknoloji sektörü öngörüleriniz neler?",
    likes: 62,
    comments: 31,
    shares: 11,
    timestamp: "Dün",
    avatar: null,
  },
];

// Örnek trendler
const sampleTrends = [
  { id: 1, topic: "#BankacılıkSektörü", postCount: 1235 },
  { id: 2, topic: "#KriptoParalar", postCount: 985 },
  { id: 3, topic: "#DövizPiyasası", postCount: 872 },
  { id: 4, topic: "#EmlakYatırımları", postCount: 754 },
  { id: 5, topic: "#OtomotivHisseleri", postCount: 631 },
];

export default function CommunityPage() {
  const [activeTab, setActiveTab] = useState("feed");
  const [postContent, setPostContent] = useState("");

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <DashboardHeader 
          title="Topluluk" 
          description="Diğer yatırımcılarla bağlantı kur, fikirlerini paylaş ve en son piyasa eğilimlerini keşfet"
        >
          <Button size="sm" className="bg-primary-600 hover:bg-primary-700">
            <Users className="mr-2 h-4 w-4" /> Bağlantıları Yönet
          </Button>
        </DashboardHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          {/* Sol sütun - Kullanıcı profili ve trendler */}
          <div className="space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Profilim</CardTitle>
                <CardDescription>Hesap detaylarınız ve istatistikleriniz</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <Avatar className="h-16 w-16">
                    <AvatarFallback className="bg-primary-100 text-primary-700 text-lg">
                      {sampleUsers[0].name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium text-lg">{sampleUsers[0].name}</h3>
                    <p className="text-sm text-gray-500">@{sampleUsers[0].username}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="bg-gray-50 p-3 rounded-md">
                    <p className="text-2xl font-bold text-primary-700">{sampleUsers[0].followers}</p>
                    <p className="text-xs text-gray-500">Takipçi</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <p className="text-2xl font-bold text-primary-700">285</p>
                    <p className="text-xs text-gray-500">Takip Edilen</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <p className="text-2xl font-bold text-primary-700">{sampleUsers[0].posts}</p>
                    <p className="text-xs text-gray-500">Gönderi</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Trend Konular</CardTitle>
                <CardDescription>Topluluğumuzda konuşulan popüler konular</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sampleTrends.map(trend => (
                    <div key={trend.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <TrendingUp className="h-4 w-4 text-primary-600" />
                        <div>
                          <p className="font-medium text-primary-700">{trend.topic}</p>
                          <p className="text-xs text-gray-500">{trend.postCount} gönderi</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-full">
                        <span className="sr-only">Takip Et</span>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Orta sütun - Gönderiler ve akış */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="pt-6">
                <Textarea 
                  placeholder="Bir şeyler paylaş..."
                  className="resize-none mb-4"
                  rows={3}
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                />
                <div className="flex justify-between">
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <ImageIcon className="h-4 w-4 mr-2" />
                      Medya
                    </Button>
                    <Button variant="outline" size="sm">
                      <BarChart2 className="h-4 w-4 mr-2" />
                      Grafik
                    </Button>
                  </div>
                  <Button size="sm" disabled={!postContent.trim()} className="bg-primary-600 hover:bg-primary-700">
                    Paylaş
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="feed">Akış</TabsTrigger>
                <TabsTrigger value="discover">Keşfet</TabsTrigger>
                <TabsTrigger value="watchlist">İzlenenler</TabsTrigger>
              </TabsList>
              
              <TabsContent value="feed" className="space-y-4 mt-4">
                {samplePosts.map(post => (
                  <Card key={post.id} className="mb-4">
                    <CardContent className="pt-6">
                      <div className="flex items-start space-x-4">
                        <Avatar>
                          <AvatarFallback className="bg-primary-100 text-primary-700">
                            {post.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{post.name}</p>
                              <p className="text-sm text-gray-500">@{post.username} · {post.timestamp}</p>
                            </div>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-full">
                              <MoreVertical className="h-4 w-4" />
                              <span className="sr-only">Daha Fazla</span>
                            </Button>
                          </div>
                          <p className="mt-2 text-gray-700">{post.content}</p>
                          <div className="flex justify-between mt-4">
                            <Button variant="ghost" size="sm" className="text-gray-500">
                              <MessageSquare className="h-4 w-4 mr-1" /> {post.comments}
                            </Button>
                            <Button variant="ghost" size="sm" className="text-gray-500">
                              <Heart className="h-4 w-4 mr-1" /> {post.likes}
                            </Button>
                            <Button variant="ghost" size="sm" className="text-gray-500">
                              <Share2 className="h-4 w-4 mr-1" /> {post.shares}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="discover" className="mt-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-12">
                      <Users className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-4 text-lg font-medium">Yeni kişileri keşfet</h3>
                      <p className="mt-2 text-gray-500">
                        Bu özellik yakında kullanıma sunulacak. İlgini çekebilecek yatırımcıları keşfetmek için takipte kal.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="watchlist" className="mt-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-12">
                      <Eye className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-4 text-lg font-medium">İzleme listesi boş</h3>
                      <p className="mt-2 text-gray-500">
                        Henüz hiçbir konu veya kişi izleme listenize eklenmedi. İlgilendiğiniz kişileri ve konuları takip etmeye başlayın.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

// Eksik bileşenler için içe aktarmalar
import { Plus, Eye, MoreVertical, ImageIcon, BarChart2 } from "lucide-react";