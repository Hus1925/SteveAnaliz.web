import { useState } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { DashboardHeader } from "@/components/dashboard-header";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs-new";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { MarketChart } from "@/components/market-chart";
import { SectorChart } from "@/components/sector-chart";
import { format } from "date-fns";
import { CalendarIcon, Download, FileText, Filter, Printer, Share2 } from "lucide-react";
import { chartData, sectorData, topStocks } from "@/lib/data/mock-data";

export default function ReportsPage() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [reportType, setReportType] = useState("weekly");

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <DashboardHeader 
            title="Financial Reports" 
            description="Generate and review comprehensive financial reports"
          />
          
          <Tabs defaultValue="generate" className="mb-6">
            <TabsList>
              <TabsTrigger value="generate">Generate Report</TabsTrigger>
              <TabsTrigger value="saved">Saved Reports</TabsTrigger>
              <TabsTrigger value="templates">Report Templates</TabsTrigger>
            </TabsList>
            
            <TabsContent value="generate">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle>Report Configuration</CardTitle>
                    <CardDescription>
                      Configure your report parameters
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <label htmlFor="report-name" className="text-sm font-medium">
                            Report Name
                          </label>
                          <Input
                            id="report-name"
                            placeholder="Enter report name"
                            defaultValue={`Financial Report - ${format(new Date(), 'MMM dd, yyyy')}`}
                          />
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium">
                            Report Type
                          </label>
                          <Select value={reportType} onValueChange={setReportType}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="daily">Daily Report</SelectItem>
                              <SelectItem value="weekly">Weekly Report</SelectItem>
                              <SelectItem value="monthly">Monthly Report</SelectItem>
                              <SelectItem value="quarterly">Quarterly Report</SelectItem>
                              <SelectItem value="annual">Annual Report</SelectItem>
                              <SelectItem value="custom">Custom Report</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium">
                            Date Range
                          </label>
                          <div className="flex flex-col space-y-2">
                            <div>
                              <label className="text-xs text-gray-500 mb-1 block">Start Date</label>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    className="w-full justify-start text-left font-normal"
                                  >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {date ? format(date, "PPP") : "Pick a start date"}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                  <Calendar
                                    mode="single"
                                    selected={date}
                                    onSelect={setDate}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                            
                            <div>
                              <label className="text-xs text-gray-500 mb-1 block">End Date</label>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    className="w-full justify-start text-left font-normal"
                                  >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {date ? format(date, "PPP") : "Pick an end date"}
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                  <Calendar
                                    mode="single"
                                    selected={date}
                                    onSelect={setDate}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">
                            Watchlist
                          </label>
                          <Select defaultValue="all">
                            <SelectTrigger>
                              <SelectValue placeholder="Select watchlist" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Stocks</SelectItem>
                              <SelectItem value="tech">Tech Leaders</SelectItem>
                              <SelectItem value="growth">Growth Potential</SelectItem>
                              <SelectItem value="dividend">Dividend Stocks</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium">
                            Analysis Criteria
                          </label>
                          <Select defaultValue="default">
                            <SelectTrigger>
                              <SelectValue placeholder="Select criteria" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="default">Default Criteria</SelectItem>
                              <SelectItem value="growth">Growth Focus</SelectItem>
                              <SelectItem value="esg">ESG Focus</SelectItem>
                              <SelectItem value="custom">Custom Analysis</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium">
                            Report Sections
                          </label>
                          <div className="mt-2 space-y-2">
                            <div className="flex items-center">
                              <input type="checkbox" id="market-overview" className="rounded" defaultChecked />
                              <label htmlFor="market-overview" className="ml-2 text-sm">Market Overview</label>
                            </div>
                            <div className="flex items-center">
                              <input type="checkbox" id="stock-analysis" className="rounded" defaultChecked />
                              <label htmlFor="stock-analysis" className="ml-2 text-sm">Stock Analysis</label>
                            </div>
                            <div className="flex items-center">
                              <input type="checkbox" id="sector-allocation" className="rounded" defaultChecked />
                              <label htmlFor="sector-allocation" className="ml-2 text-sm">Sector Allocation</label>
                            </div>
                            <div className="flex items-center">
                              <input type="checkbox" id="ai-insights" className="rounded" defaultChecked />
                              <label htmlFor="ai-insights" className="ml-2 text-sm">AI Insights</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button 
                      variant="outline"
                      onClick={() => alert("Gelişmiş rapor seçenekleri açıldı.")}
                    >
                      <Filter className="mr-2 h-4 w-4" /> Gelişmiş Seçenekler
                    </Button>
                    <Button 
                      onClick={() => {
                        alert("Rapor oluşturuluyor. Lütfen bekleyiniz...");
                        
                        // Rapor oluşturma işlemi burada gerçekleştirilecek
                        setTimeout(() => {
                          alert("Rapor başarıyla oluşturuldu!");
                        }, 1500);
                      }}
                    >
                      <FileText className="mr-2 h-4 w-4" /> Rapor Oluştur
                    </Button>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Output Format</CardTitle>
                    <CardDescription>
                      Choose your preferred report format
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Format
                      </label>
                      <Select defaultValue="pdf">
                        <SelectTrigger>
                          <SelectValue placeholder="Select format" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pdf">PDF Document</SelectItem>
                          <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                          <SelectItem value="csv">CSV File</SelectItem>
                          <SelectItem value="interactive">Interactive Web Report</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Style Template
                      </label>
                      <Select defaultValue="professional">
                        <SelectTrigger>
                          <SelectValue placeholder="Select style" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="professional">Professional</SelectItem>
                          <SelectItem value="minimal">Minimal</SelectItem>
                          <SelectItem value="detailed">Detailed</SelectItem>
                          <SelectItem value="data-focused">Data-Focused</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Report Actions
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <Button 
                          variant="outline" 
                          className="justify-start"
                          onClick={() => alert("Yazdırma işlemi başlatılıyor...")}
                        >
                          <Printer className="mr-2 h-4 w-4" /> Print
                        </Button>
                        <Button 
                          variant="outline" 
                          className="justify-start"
                          onClick={() => alert("Rapor indiriliyor...")}
                        >
                          <Download className="mr-2 h-4 w-4" /> Download
                        </Button>
                        <Button 
                          variant="outline" 
                          className="justify-start"
                          onClick={() => alert("Paylaşım seçenekleri açılıyor...")}
                        >
                          <Share2 className="mr-2 h-4 w-4" /> Share
                        </Button>
                        <Button 
                          variant="outline" 
                          className="justify-start"
                          onClick={() => alert("Rapor kaydediliyor...")}
                        >
                          <FileText className="mr-2 h-4 w-4" /> Save
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="mb-6">
                <MarketChart 
                  title="Market Performance Preview" 
                  description="Preview of the market performance section"
                  datasets={chartData}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <SectorChart 
                  title="Sector Allocation Preview" 
                  description="Preview of the sector allocation section"
                  data={sectorData}
                />
                
                <Card>
                  <CardHeader>
                    <CardTitle>AI Insights Preview</CardTitle>
                    <CardDescription>Preview of the AI insights section</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 border rounded-lg bg-gray-50">
                        <h4 className="font-medium text-gray-900 mb-2">Market Sentiment</h4>
                        <div className="flex justify-between items-center mb-1 text-xs text-gray-600">
                          <span>Bearish</span>
                          <span>Bullish</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-primary-600 h-2.5 rounded-full" style={{ width: '65%' }}></div>
                        </div>
                        <p className="text-sm text-gray-600 mt-2">
                          Our AI analysis indicates a moderately bullish market sentiment based on news, social media, and trading patterns.
                        </p>
                      </div>
                      
                      <div className="p-4 border rounded-lg bg-gray-50">
                        <h4 className="font-medium text-gray-900 mb-2">Key Recommendations</h4>
                        <ul className="space-y-2 text-sm text-gray-600">
                          <li className="flex items-start">
                            <i className="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                            <span>Consider increasing exposure to AI-related tech stocks given recent breakthroughs and adoption trends.</span>
                          </li>
                          <li className="flex items-start">
                            <i className="fas fa-exclamation-circle text-amber-500 mt-0.5 mr-2"></i>
                            <span>Monitor energy sector closely as renewable companies are gaining momentum.</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="saved">
              <div className="bg-white shadow rounded-lg overflow-hidden">
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-medium leading-6 text-gray-900">Saved Reports</h3>
                      <p className="mt-1 max-w-2xl text-sm text-gray-500">Your previously generated reports</p>
                    </div>
                    <div className="flex space-x-2">
                      <div className="relative">
                        <Input 
                          placeholder="Search reports..." 
                          className="pl-8"
                        />
                        <Filter className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      </div>
                      <Select defaultValue="newest">
                        <SelectTrigger className="w-[160px]">
                          <SelectValue placeholder="Sort by" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="newest">Newest First</SelectItem>
                          <SelectItem value="oldest">Oldest First</SelectItem>
                          <SelectItem value="a-z">Alphabetical (A-Z)</SelectItem>
                          <SelectItem value="z-a">Alphabetical (Z-A)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <div className="space-y-4">
                    {[1, 2, 3].map((item) => (
                      <Card key={item} className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="p-0">
                          <div className="flex items-center justify-between p-4 border-b">
                            <div>
                              <h4 className="font-medium text-gray-900">Weekly Market Report - May 2023</h4>
                              <p className="text-sm text-gray-500">Generated on May 15, 2023</p>
                            </div>
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => alert("Rapor indiriliyor...")}
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => alert("Paylaşım seçenekleri açılıyor...")}
                              >
                                <Share2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          <div className="grid grid-cols-3 divide-x text-center py-3">
                            <div className="px-4">
                              <div className="text-sm font-medium text-gray-900">Type</div>
                              <div className="text-sm text-gray-500">Weekly</div>
                            </div>
                            <div className="px-4">
                              <div className="text-sm font-medium text-gray-900">Stocks</div>
                              <div className="text-sm text-gray-500">25 stocks</div>
                            </div>
                            <div className="px-4">
                              <div className="text-sm font-medium text-gray-900">Format</div>
                              <div className="text-sm text-gray-500">PDF</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="templates">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  {
                    title: "Weekly Performance",
                    description: "A comprehensive weekly market and portfolio performance report",
                    sections: "Market Summary, Top Performers, Watchlist Analysis",
                    frequency: "Weekly"
                  },
                  {
                    title: "Monthly Deep Dive",
                    description: "Detailed monthly analysis with long-term trends and predictions",
                    sections: "Market Trends, Sector Analysis, AI Projections, Recommendations",
                    frequency: "Monthly"
                  },
                  {
                    title: "Quarterly Review",
                    description: "Quarterly evaluation of portfolio performance and market conditions",
                    sections: "Performance Metrics, Market Review, Sector Rotation, Strategic Recommendations",
                    frequency: "Quarterly"
                  },
                  {
                    title: "Custom Analysis",
                    description: "Build a custom report with your preferred metrics and visualizations",
                    sections: "Fully customizable",
                    frequency: "As needed"
                  },
                  {
                    title: "ESG Focus",
                    description: "Analysis focused on Environmental, Social, and Governance factors",
                    sections: "ESG Scores, Sustainability Metrics, Social Impact, Governance Quality",
                    frequency: "Monthly"
                  },
                  {
                    title: "Growth Potential",
                    description: "Focused on identifying high growth potential opportunities",
                    sections: "Growth Metrics, Innovation Scores, Market Opportunity, Risk Assessment",
                    frequency: "Biweekly"
                  }
                ].map((template, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle>{template.title}</CardTitle>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="text-sm font-medium text-gray-700">Sections</div>
                          <div className="text-sm text-gray-600">{template.sections}</div>
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-700">Recommended Frequency</div>
                          <div className="text-sm text-gray-600">{template.frequency}</div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full" 
                        onClick={() => alert("Şablon başarıyla uygulandı! Rapor oluşturma sayfasına yönlendiriliyorsunuz...")}
                      >
                        Şablonu Kullan
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
