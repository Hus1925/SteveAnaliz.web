import { useState, useRef, useEffect } from "react";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { DashboardHeader } from "@/components/dashboard-header";
import { MarketOverview } from "@/components/market-overview";
import { AnalysisCriteria } from "@/components/analysis-criteria";
import { StockTable } from "@/components/stock-table";
import { AiInsights } from "@/components/ai-insights";
import { MarketChart } from "@/components/market-chart";
import { SectorChart } from "@/components/sector-chart";
import { ActionCards } from "@/components/action-cards";
import { NewsSection } from "@/components/news-section";
import { CtaSection } from "@/components/cta-section";
import { MarketTicker, ContinuousTicker } from "@/components/market-ticker";
import { criteria, trendingSectors, aiInsights, chartData, sectorData, newsItems } from "@/lib/data/mock-data";
import { 
  globalMarkets, 
  commodities, 
  cryptoCurrencies, 
  tickerCategories, 
  continuousTickerItems, 
  preselectedStocks, 
  filteredCompanies 
} from "@/lib/data/extended-market-data";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs-new";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronDown, 
  ChevronUp, 
  Info, 
  PlayCircle,
  FileVideo,
  ExternalLink
} from "lucide-react";
import { cn, formatCurrency, formatPercentage, formatNumber } from "@/lib/utils";

export default function HomePage() {
  const [activeMarketType, setActiveMarketType] = useState("stocks");
  const [showMethodology, setShowMethodology] = useState(false);
  const methodologyRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  // Dünya borsaları göstergeleri
  const worldMarketIndices = [
    { id: "WORLD.NASDAQ", name: "NASDAQ", value: 18038.78, change: 126.25, changePercent: 0.71 },
    { id: "WORLD.DAX", name: "DAX", value: 18706.21, change: -63.15, changePercent: -0.34 },
    { id: "WORLD.FTSE", name: "FTSE 100", value: 8258.63, change: 12.31, changePercent: 0.15 },
    { id: "WORLD.NIKKEI", name: "Nikkei 225", value: 38517.30, change: -163.51, changePercent: -0.42 },
    { id: "WORLD.HANGSENG", name: "Hang Seng", value: 18502.85, change: 245.01, changePercent: 1.34 },
    { id: "WORLD.SSE", name: "Shanghai", value: 3112.57, change: -5.46, changePercent: -0.18 }
  ];
  
  // Bütün piyasa göstergeleri
  const allMarketIndices = [
    ...worldMarketIndices,
    { id: "TR.BIST100", name: "BIST 100", value: 9126.74, change: 135.29, changePercent: 1.51 },
    { id: "US.S&P500", name: "S&P 500", value: 5245.59, change: 34.16, changePercent: 0.65 },
    { id: "US.DOW", name: "Dow Jones", value: 39313.77, change: 253.26, changePercent: 0.65 }
  ];
  
  // Gösterme/gizleme durumunda metodoloji bölümüne otomatik kaydırma
  useEffect(() => {
    if (showMethodology && methodologyRef.current) {
      methodologyRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [showMethodology]);

  // Video oynatma fonksiyonu
  const playVideo = () => {
    if (videoRef.current) {
      videoRef.current.play();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
      <Header />
      
      {/* Tüm piyasa verilerini gösteren kayan bilgi bandı */}
      <ContinuousTicker items={continuousTickerItems} />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Üç sütunlu finansal dashboard başlığı */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden p-6">
              <div className="flex justify-center mb-4">
                <div className="flex-shrink-0 font-heading font-bold text-3xl text-primary-900 dark:text-primary-100">
                  <span>Steve</span><span className="text-primary-600 dark:text-primary-400">Analiz</span>
                  <span className="text-sm">.web</span>
                </div>
              </div>
              <p className="text-center text-gray-600 dark:text-gray-300">
                Profesyonel Finansal Analiz Platformu
              </p>
              <div className="mt-4 flex justify-center">
                <a href="/custom-analysis">
                  <Button 
                    variant="default" 
                    className="w-full"
                  >
                    Özel Analiz Başlat
                  </Button>
                </a>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
              <div className="relative aspect-video">
                <video 
                  ref={videoRef}
                  className="w-full h-full object-cover" 
                  poster="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&q=80"
                  controls
                >
                  <source src="https://assets.mixkit.co/videos/preview/mixkit-financial-charts-data-910-large.mp4" type="video/mp4" />
                  Tarayıcınız video etiketini desteklemiyor.
                </video>
                
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
                  <Button 
                    variant="default" 
                    className="rounded-full w-12 h-12 flex items-center justify-center" 
                    onClick={playVideo}
                  >
                    <PlayCircle className="h-8 w-8" />
                  </Button>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-medium">Piyasa Analizi</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Güncel finansal piyasa trendleri ve analiz yöntemleri</p>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden p-4">
              <h3 className="font-medium mb-2 border-b border-gray-200 dark:border-gray-700 pb-2">
                Seçilen Hisseler
              </h3>
              <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                {filteredCompanies.slice(0, 5).map((stock, index) => (
                  <div 
                    key={stock.id} 
                    className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-2"
                  >
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-xs font-medium text-primary-800 dark:text-primary-200">
                        {index + 1}
                      </div>
                      <div className="ml-3">
                        <div className="font-medium text-sm">{stock.symbol}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">{stock.name}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-sm">{formatCurrency(stock.price, "USD")}</div>
                      <div className={`text-xs ${stock.changePercent >= 0 ? "text-green-600" : "text-red-600"}`}>
                        {formatPercentage(stock.changePercent)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-3 pt-2 border-t border-gray-200 dark:border-gray-700 space-y-2">
                <Button variant="outline" size="sm" className="w-full">
                  Tüm Listeyi Gör
                </Button>
                <Button variant="outline" size="sm" className="w-full flex items-center justify-center text-primary">
                  <FileVideo className="mr-2 h-4 w-4" />
                  <span>Read to Eleven</span>
                </Button>
              </div>
            </div>
          </div>
          
          {/* Metodoloji açıklama bölümü - Ana sayfaya taşındı */}
          <div className="mb-8 bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-bold">Analiz Metodolojimiz</h2>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                SteveAnaliz.web, finansal araçları değerlendirmek için kapsamlı bir analiz sistemi kullanır
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6">
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  SteveAnaliz.web, hisse senetlerini değerlendirmek için özel olarak geliştirilmiş 7 kritere dayalı bir sistem kullanır. 
                  Bu kriterler finansal sağlık, büyüme potansiyeli, sektör konumu, inovasyon kapasitesi, topluluk etkileşimi, 
                  ESG faktörleri ve yapay zeka destekli duyarlılık analizini kapsar.
                </p>
                
                <div className="space-y-3 mb-4 mt-6">
                  <div className="flex items-start bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg">
                    <div className="bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">1</div>
                    <div>
                      <h4 className="font-medium">Ön Eleme Aşaması</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">50 şirketlik bir havuzdan başlayarak her kritere göre ön değerlendirme yapılır.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg">
                    <div className="bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">2</div>
                    <div>
                      <h4 className="font-medium">Ağırlıklandırma</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Her kritere belirli bir ağırlık verilir ve şirketler bu ağırlıklara göre puanlanır.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg">
                    <div className="bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">3</div>
                    <div>
                      <h4 className="font-medium">Filtreleme ve Sıralama</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">En yüksek puana sahip 7-10 şirket seçilir ve detaylı analiz için sunulur.</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <a href="/custom-analysis">
                    <Button variant="default">
                      Özel Analiz Oluştur
                    </Button>
                  </a>
                </div>
              </div>
              
              <div className="p-6 border-l border-gray-200 dark:border-gray-700">
                <h3 className="font-medium mb-4">7 Kritere Dayalı Analiz Sistemi</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {criteria.map(criterion => (
                    <div 
                      key={criterion.id} 
                      className="p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-sm">{criterion.title}</h4>
                        <Badge variant="outline">
                          {criterion.weight}%
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {criterion.description}
                      </p>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 bg-gray-50 dark:bg-gray-900/50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Eğitim İçerikleri</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <Button variant="outline" className="justify-start h-auto py-2">
                      <FileVideo className="mr-2 h-4 w-4" />
                      <div className="text-left text-xs">
                        <div className="font-medium">Temel Analiz</div>
                      </div>
                    </Button>
                    
                    <Button variant="outline" className="justify-start h-auto py-2">
                      <FileVideo className="mr-2 h-4 w-4" />
                      <div className="text-left text-xs">
                        <div className="font-medium">Teknik Analiz</div>
                      </div>
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="justify-start h-auto py-2"
                      onClick={() => window.open("https://www.youtube.com/watch?v=Xn7KWR9EOGQ", "_blank")}
                    >
                      <ExternalLink className="mr-2 h-4 w-4" />
                      <div className="text-left text-xs">
                        <div className="font-medium">YouTube</div>
                      </div>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Piyasa verileri sekmeler ve kayan bantlar */}
          <div className="mb-6">
            <Tabs defaultValue="stocks" onValueChange={setActiveMarketType}>
              <div className="flex justify-between items-center mb-4">
                <TabsList>
                  <TabsTrigger value="stocks">Borsalar</TabsTrigger>
                  <TabsTrigger value="crypto">Kripto</TabsTrigger>
                  <TabsTrigger value="commodities">Emtia</TabsTrigger>
                  <TabsTrigger value="forex">Döviz</TabsTrigger>
                </TabsList>
                
                <Button variant="ghost" size="sm" className="text-xs">
                  Daha Fazla Göster
                </Button>
              </div>
              
              <TabsContent value="stocks">
                <div className="overflow-hidden py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                  <div className="animate-marquee whitespace-nowrap flex space-x-4 px-4">
                    {tickerCategories[0].items.map((item, index) => (
                      <div 
                        key={`stock-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Tekrarlayan öğeler - sonsuz kaydırma için */}
                    {tickerCategories[0].items.map((item, index) => (
                      <div 
                        key={`stock-repeat-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="crypto">
                <div className="overflow-hidden py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                  <div className="animate-marquee whitespace-nowrap flex space-x-4 px-4">
                    {tickerCategories[2].items.map((item, index) => (
                      <div 
                        key={`crypto-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Tekrarlayan öğeler - sonsuz kaydırma için */}
                    {tickerCategories[2].items.map((item, index) => (
                      <div 
                        key={`crypto-repeat-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="commodities">
                <div className="overflow-hidden py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                  <div className="animate-marquee whitespace-nowrap flex space-x-4 px-4">
                    {tickerCategories[1].items.map((item, index) => (
                      <div 
                        key={`commodity-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Tekrarlayan öğeler - sonsuz kaydırma için */}
                    {tickerCategories[1].items.map((item, index) => (
                      <div 
                        key={`commodity-repeat-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="forex">
                <div className="overflow-hidden py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                  <div className="animate-marquee whitespace-nowrap flex space-x-4 px-4">
                    {tickerCategories[3].items.map((item, index) => (
                      <div 
                        key={`forex-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Tekrarlayan öğeler - sonsuz kaydırma için */}
                    {tickerCategories[3].items.map((item, index) => (
                      <div 
                        key={`forex-repeat-${item.symbol}-${index}`}
                        className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                      >
                        <div className="mr-3">
                          <div className="font-medium text-sm">{item.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{formatCurrency(item.value, "USD")}</div>
                          <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercent)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Dünya Borsaları Kayan Gösterge */}
          <div className="mb-6">
            <h3 className="text-sm font-medium mb-3">Dünya Borsaları</h3>
            <div className="overflow-hidden py-2 bg-white dark:bg-gray-800 rounded-lg shadow-md">
              <div className="animate-marquee whitespace-nowrap flex space-x-4 px-4">
                {worldMarketIndices.map((item, index) => (
                  <div 
                    key={`${item.name}-${index}`}
                    className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                  >
                    <div className="mr-3">
                      <div className="font-medium text-sm">{item.name}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">{item.id}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-sm">{formatNumber(item.value)}</div>
                      <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercentage || item.changePercent || 0)}
                      </div>
                    </div>
                  </div>
                ))}
                {worldMarketIndices.map((item, index) => (
                  <div 
                    key={`${item.name}-repeat-${index}`}
                    className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800"
                  >
                    <div className="mr-3">
                      <div className="font-medium text-sm">{item.name}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">{item.id}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-sm">{formatNumber(item.value)}</div>
                      <div className={`text-xs flex items-center ${item.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {item.change >= 0 ? '▲' : '▼'} {formatPercentage(item.changePercentage || item.changePercent || 0)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <MarketOverview indices={allMarketIndices.filter(idx => !idx.id.includes("WORLD"))} />
          
          <AnalysisCriteria criteria={criteria} />
          
          {/* Ön seçim havuzu ve filtrelenmiş hisseler */}
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Ön Seçim Havuzu ve Analiz Sonuçları</CardTitle>
                <CardDescription>
                  Başlangıç havuzundaki 50 şirket arasından 7 kriterli analiz sistemimizle seçilen en iyi 10 şirket
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <h4 className="text-sm font-medium mb-2">Filtreleme Süreci:</h4>
                  <div className="flex items-center overflow-x-auto pb-2 scrollbar-hide">
                    <div className="bg-gray-100 dark:bg-gray-800 rounded px-3 py-1.5 text-sm font-medium flex items-center whitespace-nowrap">
                      <span className="text-gray-500 mr-2">Başlangıç Havuzu:</span>
                      <span className="text-primary-600 dark:text-primary-400">{preselectedStocks.length} Şirket</span>
                    </div>
                    <div className="mx-2 text-gray-300 dark:text-gray-700">→</div>
                    <div className="bg-gray-100 dark:bg-gray-800 rounded px-3 py-1.5 text-sm font-medium flex items-center whitespace-nowrap">
                      <span className="text-gray-500 mr-2">Kriter Analizi</span>
                    </div>
                    <div className="mx-2 text-gray-300 dark:text-gray-700">→</div>
                    <div className="bg-primary-50 dark:bg-primary-900/20 border border-primary-200 dark:border-primary-800 rounded px-3 py-1.5 text-sm font-medium flex items-center whitespace-nowrap">
                      <span className="text-primary-700 dark:text-primary-300 mr-2">Sonuç:</span>
                      <span className="text-primary-600 dark:text-primary-400">{filteredCompanies.length} Şirket</span>
                    </div>
                  </div>
                </div>
                
                {/* Ön seçim havuzu tablosu */}
                <div className="border rounded-lg overflow-hidden mb-4">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-800">
                      <thead className="bg-gray-50 dark:bg-gray-800">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Sembol</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Şirket</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Sektör</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Ülke</th>
                          <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Piyasa Değeri</th>
                          <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Analiz Puanı</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-800">
                        {preselectedStocks.slice(0, 5).map((stock) => (
                          <tr key={stock.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{stock.symbol}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">{stock.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">{stock.sector}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">{stock.country}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 text-right">{formatCurrency(stock.marketCap / 1000000000, "USD")}B</td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <Badge className={cn(
                                stock.score >= 80 ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300" :
                                stock.score >= 70 ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-300" :
                                stock.score >= 60 ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300" :
                                "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300"
                              )}>
                                {stock.score}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 text-right">
                    <Button variant="ghost" size="sm">
                      Tüm Listeyi Gör
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="flex flex-col md:flex-row gap-6 mb-8">
            <div className="w-full md:w-2/3">
              <StockTable 
                stocks={filteredCompanies} 
                title="En İyi Hisseler" 
                description="7 kriterli analize dayalı olarak"
              />
            </div>
            
            <div className="w-full md:w-1/3">
              <AiInsights 
                sentimentScore={65} 
                trendingSectors={trendingSectors}
                insights={aiInsights}
              />
            </div>
          </div>
          
          <div className="flex flex-col xl:flex-row gap-6 mb-8">
            <div className="w-full xl:w-2/3">
              <MarketChart 
                title="Piyasa Performansı" 
                description="Tarihsel veriler ve trendler"
                datasets={chartData}
              />
            </div>
            
            <div className="w-full xl:w-1/3">
              <SectorChart 
                title="Sektör Dağılımı" 
                description="Endüstri sektörüne göre dağılım"
                data={sectorData}
              />
            </div>
          </div>
          
          <ActionCards />
          
          <NewsSection newsItems={newsItems} />
          
          <CtaSection />
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
