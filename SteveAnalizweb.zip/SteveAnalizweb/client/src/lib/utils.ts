import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format currency with appropriate precision and symbol
export function formatCurrency(value: number, currency: string = "USD", locale: string = "en-US") {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: currency,
  }).format(value);
}

// Format percentage with appropriate precision
export function formatPercentage(value: number, precision: number = 2) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(precision)}%`;
}

// Format large numbers with abbreviations (K, M, B)
export function formatNumber(value: number) {
  if (value >= 1000000000) {
    return `${(value / 1000000000).toFixed(1)}B`;
  } else if (value >= 1000000) {
    return `${(value / 1000000).toFixed(1)}M`;
  } else if (value >= 1000) {
    return `${(value / 1000).toFixed(1)}K`;
  }
  return value.toString();
}

// Calculate the color for a score based on a range
export function getScoreColor(score: number, maxScore: number = 100) {
  if (score >= maxScore * 0.8) {
    return "bg-green-100 text-green-800"; // Strong Buy
  } else if (score >= maxScore * 0.6) {
    return "bg-emerald-100 text-emerald-800"; // Buy
  } else if (score >= maxScore * 0.4) {
    return "bg-yellow-100 text-yellow-800"; // Hold
  } else if (score >= maxScore * 0.2) {
    return "bg-orange-100 text-orange-800"; // Sell
  } else {
    return "bg-red-100 text-red-800"; // Strong Sell
  }
}

// Get recommendation text based on score
export function getRecommendation(score: number, maxScore: number = 100) {
  if (score >= maxScore * 0.8) {
    return "Strong Buy";
  } else if (score >= maxScore * 0.6) {
    return "Buy";
  } else if (score >= maxScore * 0.4) {
    return "Hold";
  } else if (score >= maxScore * 0.2) {
    return "Sell";
  } else {
    return "Strong Sell";
  }
}

// Generate a random stock trend path for visualization
export function generateTrendPath(isPositive: boolean = true) {
  const points = [];
  const pointCount = 10;
  
  for (let i = 0; i < pointCount; i++) {
    const x = (i * 50) / (pointCount - 1);
    let y = 10;
    
    if (isPositive) {
      y = 10 - (i * 5) / pointCount + Math.random() * 3;
    } else {
      y = 10 + (i * 5) / pointCount + Math.random() * 3;
    }
    
    points.push(`${x},${y}`);
  }
  
  return `M${points.join(" L")}`;
}

// Truncate text to a certain length
export function truncateText(text: string, maxLength: number = 50) {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + "...";
}

// Check if a stock is in the provided watchlist
export function isStockInWatchlist(stockId: string, watchlistId: string, watchlists: any[]) {
  const watchlist = watchlists.find(wl => wl.id === watchlistId);
  if (!watchlist) return false;
  return watchlist.stocks.some((stock: any) => stock.id === stockId);
}
