// Genişletilmiş piyasa verileri

// Dünya Borsaları
export const globalMarkets = [
  {
    id: "sp500",
    name: "S&P 500",
    symbol: "SPX",
    value: 4587.98,
    change: -19.31,
    changePercent: -0.42,
    type: "index",
    region: "US"
  },
  {
    id: "dow",
    name: "Dow Jones",
    symbol: "DJI",
    value: 37210.50,
    change: 112.78,
    changePercent: 0.31,
    type: "index",
    region: "US"
  },
  {
    id: "nasdaq",
    name: "NASDAQ",
    symbol: "IXIC",
    value: 14189.64,
    change: 90.81,
    changePercent: 0.64,
    type: "index",
    region: "US"
  },
  {
    id: "ftse",
    name: "FTSE 100",
    symbol: "UKX",
    value: 7741.32,
    change: -18.45,
    changePercent: -0.24,
    type: "index",
    region: "UK"
  },
  {
    id: "dax",
    name: "DAX",
    symbol: "GDAXI",
    value: 17628.40,
    change: 42.91,
    changePercent: 0.24,
    type: "index",
    region: "Germany"
  },
  {
    id: "cac",
    name: "CAC 40",
    symbol: "FCHI",
    value: 7502.73,
    change: -12.82,
    changePercent: -0.17,
    type: "index",
    region: "France"
  },
  {
    id: "nikkei",
    name: "Nikkei 225",
    symbol: "N225",
    value: 37914.28,
    change: 523.89,
    changePercent: 1.40,
    type: "index",
    region: "Japan"
  },
  {
    id: "hsi",
    name: "Hang Seng",
    symbol: "HSI",
    value: 16512.45,
    change: -125.33,
    changePercent: -0.75,
    type: "index",
    region: "Hong Kong"
  },
  {
    id: "bist100",
    name: "BIST 100",
    symbol: "XU100",
    value: 8124.36,
    change: 106.24,
    changePercent: 1.32,
    type: "index",
    region: "Turkey"
  }
];

// Emtia & Metaller
export const commodities = [
  {
    id: "gold",
    name: "Gold",
    symbol: "XAU",
    value: 2314.80,
    change: 12.50,
    changePercent: 0.54,
    type: "commodity",
    category: "Precious Metals"
  },
  {
    id: "silver",
    name: "Silver",
    symbol: "XAG",
    value: 27.42,
    change: 0.18,
    changePercent: 0.66,
    type: "commodity",
    category: "Precious Metals"
  },
  {
    id: "platinum",
    name: "Platinum",
    symbol: "PL",
    value: 939.70,
    change: -5.30,
    changePercent: -0.56,
    type: "commodity",
    category: "Precious Metals"
  },
  {
    id: "copper",
    name: "Copper",
    symbol: "HG",
    value: 4.52,
    change: 0.04,
    changePercent: 0.89,
    type: "commodity",
    category: "Base Metals"
  },
  {
    id: "crude_oil",
    name: "Crude Oil",
    symbol: "CL",
    value: 78.92,
    change: -1.18,
    changePercent: -1.47,
    type: "commodity",
    category: "Energy"
  },
  {
    id: "natural_gas",
    name: "Natural Gas",
    symbol: "NG",
    value: 2.12,
    change: 0.04,
    changePercent: 1.92,
    type: "commodity",
    category: "Energy"
  },
  {
    id: "corn",
    name: "Corn",
    symbol: "ZC",
    value: 438.25,
    change: 2.25,
    changePercent: 0.52,
    type: "commodity",
    category: "Agriculture"
  },
  {
    id: "wheat",
    name: "Wheat",
    symbol: "ZW",
    value: 624.75,
    change: -8.50,
    changePercent: -1.34,
    type: "commodity",
    category: "Agriculture"
  }
];

// Kripto Para Birimleri
export const cryptoCurrencies = [
  {
    id: "bitcoin",
    name: "Bitcoin",
    symbol: "BTC",
    value: 62784.50,
    change: 1245.30,
    changePercent: 2.02,
    type: "crypto",
    marketCap: 1213578000000
  },
  {
    id: "ethereum",
    name: "Ethereum",
    symbol: "ETH",
    value: 3045.78,
    change: 78.34,
    changePercent: 2.64,
    type: "crypto",
    marketCap: 366280000000
  },
  {
    id: "bnb",
    name: "BNB",
    symbol: "BNB",
    value: 574.12,
    change: -8.23,
    changePercent: -1.41,
    type: "crypto",
    marketCap: 87520000000
  },
  {
    id: "solana",
    name: "Solana",
    symbol: "SOL",
    value: 134.67,
    change: 5.82,
    changePercent: 4.52,
    type: "crypto",
    marketCap: 58420000000
  },
  {
    id: "xrp",
    name: "XRP",
    symbol: "XRP",
    value: 0.5078,
    change: 0.0012,
    changePercent: 0.24,
    type: "crypto",
    marketCap: 28910000000
  },
  {
    id: "cardano",
    name: "Cardano",
    symbol: "ADA",
    value: 0.4523,
    change: 0.0215,
    changePercent: 4.99,
    type: "crypto",
    marketCap: 16140000000
  }
];

// Dövizler
export const currencies = [
  {
    id: "eur_usd",
    name: "EUR/USD",
    symbol: "EUR/USD",
    value: 1.0724,
    change: -0.0008,
    changePercent: -0.07,
    type: "currency"
  },
  {
    id: "gbp_usd",
    name: "GBP/USD",
    symbol: "GBP/USD",
    value: 1.2512,
    change: 0.0024,
    changePercent: 0.19,
    type: "currency"
  },
  {
    id: "usd_jpy",
    name: "USD/JPY",
    symbol: "USD/JPY",
    value: 154.82,
    change: 0.45,
    changePercent: 0.29,
    type: "currency"
  },
  {
    id: "usd_try",
    name: "USD/TRY",
    symbol: "USD/TRY",
    value: 32.14,
    change: 0.03,
    changePercent: 0.09,
    type: "currency"
  },
  {
    id: "eur_try",
    name: "EUR/TRY",
    symbol: "EUR/TRY",
    value: 34.46,
    change: 0.12,
    changePercent: 0.35,
    type: "currency"
  }
];

// Ön-seçilmiş şirket havuzu (detaylı özelliklerle)
export const preselectedStocks = [
  {
    id: "TSLA",
    symbol: "TSLA",
    name: "Tesla Inc.",
    exchange: "NASDAQ",
    sector: "Consumer Discretionary",
    industry: "Auto Manufacturers",
    country: "United States",
    marketCap: 775420000000,
    price: 824.40,
    change: 26.32,
    changePercent: 3.2,
    volume: 28750000,
    avgVolume: 31250000,
    peRatio: 85.12,
    eps: 9.69,
    dividend: 0,
    dividendYield: 0,
    targetPrice: 875.50,
    analystRating: "Buy",
    revenue: 96773000000,
    revenueGrowth: 25.4,
    profitMargin: 15.2,
    debtToEquity: 0.32,
    roa: 9.8,
    roe: 24.3,
    esgScore: 72,
    innovationScore: 92,
    score: 87
  },
  {
    id: "NVDA",
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    exchange: "NASDAQ",
    sector: "Information Technology",
    industry: "Semiconductors",
    country: "United States",
    marketCap: 1850000000000,
    price: 267.58,
    change: 7.49,
    changePercent: 2.8,
    volume: 36240000,
    avgVolume: 42180000,
    peRatio: 62.34,
    eps: 7.03,
    dividend: 0.16,
    dividendYield: 0.06,
    targetPrice: 280.20,
    analystRating: "Strong Buy",
    revenue: 60922000000,
    revenueGrowth: 125.7,
    profitMargin: 48.3,
    debtToEquity: 0.18,
    roa: 35.2,
    roe: 86.4,
    esgScore: 68,
    innovationScore: 94,
    score: 83
  },
  {
    id: "AAPL",
    symbol: "AAPL",
    name: "Apple Inc.",
    exchange: "NASDAQ",
    sector: "Information Technology",
    industry: "Consumer Electronics",
    country: "United States",
    marketCap: 2720000000000,
    price: 176.28,
    change: -1.42,
    changePercent: -0.8,
    volume: 45230000,
    avgVolume: 51820000,
    peRatio: 29.12,
    eps: 6.08,
    dividend: 0.96,
    dividendYield: 0.54,
    targetPrice: 185.40,
    analystRating: "Buy",
    revenue: 383292000000,
    revenueGrowth: 2.1,
    profitMargin: 25.6,
    debtToEquity: 1.28,
    roa: 21.2,
    roe: 145.3,
    esgScore: 82,
    innovationScore: 85,
    score: 79
  },
  {
    id: "META",
    symbol: "META",
    name: "Meta Platforms",
    exchange: "NASDAQ",
    sector: "Communication Services",
    industry: "Internet Content & Information",
    country: "United States",
    marketCap: 908000000000,
    price: 352.92,
    change: 5.22,
    changePercent: 1.5,
    volume: 14520000,
    avgVolume: 16840000,
    peRatio: 33.57,
    eps: 10.51,
    dividend: 0,
    dividendYield: 0,
    targetPrice: 370.80,
    analystRating: "Buy",
    revenue: 134900000000,
    revenueGrowth: 15.8,
    profitMargin: 32.6,
    debtToEquity: 0.13,
    roa: 19.8,
    roe: 25.2,
    esgScore: 63,
    innovationScore: 82,
    score: 76
  },
  {
    id: "MSFT",
    symbol: "MSFT",
    name: "Microsoft Corp.",
    exchange: "NASDAQ",
    sector: "Information Technology",
    industry: "Software—Infrastructure",
    country: "United States",
    marketCap: 2910000000000,
    price: 326.80,
    change: -0.65,
    changePercent: -0.2,
    volume: 21360000,
    avgVolume: 24750000,
    peRatio: 31.42,
    eps: 10.40,
    dividend: 3.00,
    dividendYield: 0.92,
    targetPrice: 340.60,
    analystRating: "Strong Buy",
    revenue: 212350000000,
    revenueGrowth: 13.2,
    profitMargin: 36.8,
    debtToEquity: 0.35,
    roa: 18.6,
    roe: 44.2,
    esgScore: 85,
    innovationScore: 88,
    score: 75
  },
  {
    id: "ASML",
    symbol: "ASML",
    name: "ASML Holding",
    exchange: "NASDAQ",
    sector: "Information Technology",
    industry: "Semiconductor Equipment & Materials",
    country: "Netherlands",
    marketCap: 345000000000,
    price: 872.36,
    change: 15.42,
    changePercent: 1.8,
    volume: 1250000,
    avgVolume: 1480000,
    peRatio: 49.85,
    eps: 17.50,
    dividend: 5.85,
    dividendYield: 0.67,
    targetPrice: 910.20,
    analystRating: "Buy",
    revenue: 28140000000,
    revenueGrowth: 10.5,
    profitMargin: 33.2,
    debtToEquity: 0.42,
    roa: 16.9,
    roe: 61.8,
    esgScore: 76,
    innovationScore: 90,
    score: 78
  },
  {
    id: "AMZN",
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    exchange: "NASDAQ",
    sector: "Consumer Discretionary",
    industry: "Internet Retail",
    country: "United States",
    marketCap: 1680000000000,
    price: 162.15,
    change: 1.25,
    changePercent: 0.8,
    volume: 35420000,
    avgVolume: 42650000,
    peRatio: 56.32,
    eps: 2.88,
    dividend: 0,
    dividendYield: 0,
    targetPrice: 175.40,
    analystRating: "Strong Buy",
    revenue: 574780000000,
    revenueGrowth: 12.3,
    profitMargin: 5.8,
    debtToEquity: 0.58,
    roa: 4.2,
    roe: 14.5,
    esgScore: 68,
    innovationScore: 86,
    score: 80
  },
  {
    id: "GOOG",
    symbol: "GOOG",
    name: "Alphabet Inc.",
    exchange: "NASDAQ",
    sector: "Communication Services",
    industry: "Internet Content & Information",
    country: "United States",
    marketCap: 1820000000000,
    price: 143.68,
    change: 0.95,
    changePercent: 0.7,
    volume: 18750000,
    avgVolume: 22450000,
    peRatio: 24.74,
    eps: 5.80,
    dividend: 0,
    dividendYield: 0,
    targetPrice: 155.30,
    analystRating: "Strong Buy",
    revenue: 307395000000,
    revenueGrowth: 13.5,
    profitMargin: 24.2,
    debtToEquity: 0.06,
    roa: 15.8,
    roe: 26.1,
    esgScore: 75,
    innovationScore: 89,
    score: 82
  },
  {
    id: "ASELSAN",
    symbol: "ASELS",
    name: "Aselsan",
    exchange: "BIST",
    sector: "Industrials",
    industry: "Aerospace & Defense",
    country: "Turkey",
    marketCap: 150000000000,
    price: 42.86,
    change: 0.68,
    changePercent: 1.61,
    volume: 9840000,
    avgVolume: 11250000,
    peRatio: 6.12,
    eps: 7.00,
    dividend: 1.20,
    dividendYield: 2.80,
    targetPrice: 48.50,
    analystRating: "Buy",
    revenue: 45300000000,
    revenueGrowth: 28.6,
    profitMargin: 18.4,
    debtToEquity: 0.32,
    roa: 12.5,
    roe: 24.8,
    esgScore: 65,
    innovationScore: 75,
    score: 72
  },
  {
    id: "KOC",
    symbol: "KCHOL",
    name: "Koç Holding",
    exchange: "BIST",
    sector: "Industrials",
    industry: "Conglomerates",
    country: "Turkey",
    marketCap: 145000000000,
    price: 124.50,
    change: 2.50,
    changePercent: 2.05,
    volume: 5260000,
    avgVolume: 6420000,
    peRatio: 5.43,
    eps: 22.93,
    dividend: 4.80,
    dividendYield: 3.85,
    targetPrice: 135.70,
    analystRating: "Buy",
    revenue: 970500000000,
    revenueGrowth: 18.3,
    profitMargin: 8.2,
    debtToEquity: 1.05,
    roa: 6.8,
    roe: 22.4,
    esgScore: 70,
    innovationScore: 68,
    score: 74
  }
];

// Ticker grupları için veri hazırlama
export const tickerCategories = [
  {
    title: "Dünya Borsaları",
    items: globalMarkets.map(item => ({
      name: item.name,
      symbol: item.symbol,
      value: item.value,
      change: item.change,
      changePercent: item.changePercent,
      type: "index" as const
    }))
  },
  {
    title: "Emtia & Metaller",
    items: commodities.map(item => ({
      name: item.name,
      symbol: item.symbol,
      value: item.value,
      change: item.change,
      changePercent: item.changePercent,
      type: "commodity" as const,
      currency: item.id === "crude_oil" || item.id === "natural_gas" ? "USD" : "USD"
    }))
  },
  {
    title: "Kripto Para Birimleri",
    items: cryptoCurrencies.map(item => ({
      name: item.name,
      symbol: item.symbol,
      value: item.value,
      change: item.change,
      changePercent: item.changePercent,
      type: "crypto" as const,
      currency: "USD"
    }))
  },
  {
    title: "Dövizler",
    items: currencies.map(item => ({
      name: item.name,
      symbol: item.symbol,
      value: item.value,
      change: item.change,
      changePercent: item.changePercent,
      type: "stock" as const
    }))
  }
];

// Analiz için ön-filtrelenmiş şirketler (performansa göre en iyi 10)
export const filteredCompanies = preselectedStocks
  .sort((a, b) => b.score - a.score)
  .slice(0, 10);

// Sürekli akan ticker için veri
export const continuousTickerItems = [
  ...globalMarkets.map(item => ({
    name: item.name,
    symbol: item.symbol,
    value: item.value,
    change: item.change,
    changePercent: item.changePercent,
    type: "index" as const
  })),
  ...cryptoCurrencies.map(item => ({
    name: item.name,
    symbol: item.symbol,
    value: item.value,
    change: item.change,
    changePercent: item.changePercent,
    type: "crypto" as const
  })),
  ...commodities.slice(0, 4).map(item => ({
    name: item.name,
    symbol: item.symbol,
    value: item.value,
    change: item.change,
    changePercent: item.changePercent,
    type: "commodity" as const
  }))
];