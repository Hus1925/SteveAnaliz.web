// Finansal analiz için kullanılabilecek tüm kriterler
export interface AnalysisCriterion {
  id: string;
  name: string;
  description: string;
  category: 'financial' | 'technical' | 'fundamental' | 'esg' | 'sentiment' | 'ai';
  defaultWeight: number;
}

// Kullanıcının seçtiği kriter
export interface SelectedCriterion extends AnalysisCriterion {
  weight: number; // Kullanıcının belirlediği ağırlık (1-100)
  enabled: boolean;
}

// Kriterler kategorilere ayrılarak sunulacak
export const availableCriteria: AnalysisCriterion[] = [
  // Finansal Kriterler
  {
    id: "eps",
    name: "Hisse Başı Kazanç (EPS)",
    description: "Şirketin net gelirinin toplam hisse sayısına bölünmesi",
    category: 'financial',
    defaultWeight: 80,
  },
  {
    id: "pe_ratio",
    name: "F/K Oranı",
    description: "Hisse fiyatının hisse başı kazanca oranı",
    category: 'financial',
    defaultWeight: 75,
  },
  {
    id: "revenue_growth",
    name: "Gelir Büyümesi",
    description: "Yıllık bazda gelir büyüme yüzdesi",
    category: 'financial',
    defaultWeight: 85,
  },
  {
    id: "profit_margin",
    name: "Kar Marjı",
    description: "Net karın toplam gelire oranı",
    category: 'financial',
    defaultWeight: 80,
  },
  {
    id: "debt_to_equity",
    name: "Borç/Özsermaye Oranı",
    description: "Toplam borcun özsermayeye oranı",
    category: 'financial',
    defaultWeight: 70,
  },
  {
    id: "roa",
    name: "Aktif Karlılık (ROA)",
    description: "Net karın toplam varlıklara oranı",
    category: 'financial',
    defaultWeight: 75,
  },
  {
    id: "roe",
    name: "Özsermaye Karlılığı (ROE)",
    description: "Net karın özsermayeye oranı",
    category: 'financial',
    defaultWeight: 80,
  },
  {
    id: "current_ratio",
    name: "Cari Oran",
    description: "Dönen varlıkların kısa vadeli borçlara oranı",
    category: 'financial',
    defaultWeight: 65,
  },
  {
    id: "quick_ratio",
    name: "Asit-Test Oranı",
    description: "Dönen varlıklar (stoklar hariç) / kısa vadeli borçlar",
    category: 'financial',
    defaultWeight: 60,
  },
  {
    id: "dividend_yield",
    name: "Temettü Verimi",
    description: "Yıllık temettünün hisse fiyatına oranı",
    category: 'financial',
    defaultWeight: 50,
  },
  {
    id: "payout_ratio",
    name: "Dağıtım Oranı",
    description: "Temettü olarak dağıtılan kazanç yüzdesi",
    category: 'financial',
    defaultWeight: 40,
  },
  
  // Teknik Kriterler
  {
    id: "sma_50_200",
    name: "50/200 Günlük Ortalama",
    description: "50 günlük ortalama, 200 günlük ortalamanın üzerinde mi?",
    category: 'technical',
    defaultWeight: 60,
  },
  {
    id: "rsi",
    name: "Göreceli Güç Endeksi (RSI)",
    description: "Fiyat değişimlerinin büyüklüğünü ve hızını ölçen gösterge",
    category: 'technical',
    defaultWeight: 65,
  },
  {
    id: "macd",
    name: "MACD",
    description: "Fiyat trendinin gücünü, yönünü ve momentumunu ölçen gösterge",
    category: 'technical',
    defaultWeight: 60,
  },
  {
    id: "bollinger_bands",
    name: "Bollinger Bantları",
    description: "Fiyat oynaklığını, aşırı alım/satım durumlarını gösteren gösterge",
    category: 'technical',
    defaultWeight: 55,
  },
  {
    id: "volume_change",
    name: "İşlem Hacmi Değişimi",
    description: "Ortalama işlem hacmine göre değişim",
    category: 'technical',
    defaultWeight: 50,
  },
  {
    id: "price_momentum",
    name: "Fiyat Momentumu",
    description: "Belirli bir dönemdeki fiyat değişiminin yönü ve gücü",
    category: 'technical',
    defaultWeight: 70,
  },
  
  // Temel Kriterler
  {
    id: "market_share",
    name: "Pazar Payı",
    description: "Şirketin ilgili sektördeki pazar payı",
    category: 'fundamental',
    defaultWeight: 75,
  },
  {
    id: "competitive_advantage",
    name: "Rekabet Avantajı",
    description: "Şirketin rekabetçi pozisyonu ve avantajları",
    category: 'fundamental',
    defaultWeight: 80,
  },
  {
    id: "management_quality",
    name: "Yönetim Kalitesi",
    description: "Şirket yönetiminin tecrübesi ve performansı",
    category: 'fundamental',
    defaultWeight: 70,
  },
  {
    id: "industry_growth",
    name: "Sektör Büyümesi",
    description: "Şirketin faaliyet gösterdiği sektörün büyüme potansiyeli",
    category: 'fundamental',
    defaultWeight: 75,
  },
  {
    id: "innovation",
    name: "İnovasyon",
    description: "Şirketin Ar-Ge yatırımları ve inovasyon kapasitesi",
    category: 'fundamental',
    defaultWeight: 65,
  },
  {
    id: "brand_strength",
    name: "Marka Gücü",
    description: "Şirketin marka değeri ve tanınırlığı",
    category: 'fundamental',
    defaultWeight: 60,
  },
  
  // ESG Kriterler
  {
    id: "carbon_footprint",
    name: "Karbon Ayak İzi",
    description: "Şirketin karbon emisyonları ve çevresel etkileri",
    category: 'esg',
    defaultWeight: 40,
  },
  {
    id: "sustainable_practices",
    name: "Sürdürülebilir Uygulamalar",
    description: "Şirketin sürdürülebilirlik politikaları ve uygulamaları",
    category: 'esg',
    defaultWeight: 45,
  },
  {
    id: "corporate_governance",
    name: "Kurumsal Yönetişim",
    description: "Şirketin şeffaflık, hesap verebilirlik ve etik standartları",
    category: 'esg',
    defaultWeight: 55,
  },
  {
    id: "social_impact",
    name: "Sosyal Etki",
    description: "Şirketin toplum ve çalışanlar üzerindeki etkisi",
    category: 'esg',
    defaultWeight: 50,
  },
  
  // Duyarlılık Kriterleri
  {
    id: "analyst_ratings",
    name: "Analist Değerlendirmeleri",
    description: "Şirket hakkındaki analist görüşleri ve tavsiyeler",
    category: 'sentiment',
    defaultWeight: 60,
  },
  {
    id: "insider_trading",
    name: "İçeriden İşlemler",
    description: "Şirket yöneticilerinin hisse alım/satım işlemleri",
    category: 'sentiment',
    defaultWeight: 55,
  },
  {
    id: "news_sentiment",
    name: "Haber Duyarlılığı",
    description: "Şirket hakkındaki haberlerin duyarlılık analizi",
    category: 'sentiment',
    defaultWeight: 50,
  },
  {
    id: "social_media_sentiment",
    name: "Sosyal Medya Duyarlılığı",
    description: "Sosyal medyada şirket hakkındaki yorumların analizi",
    category: 'sentiment',
    defaultWeight: 45,
  },
  
  // Yapay Zeka Kriterleri
  {
    id: "ai_trend_prediction",
    name: "YZ Trend Tahmini",
    description: "Yapay zeka algoritmaları ile öngörülen fiyat trendi",
    category: 'ai',
    defaultWeight: 60,
  },
  {
    id: "ai_sentiment_analysis",
    name: "YZ Duyarlılık Analizi",
    description: "Yapay zeka ile analiz edilen şirket duyarlılığı",
    category: 'ai',
    defaultWeight: 55,
  },
  {
    id: "ai_growth_prediction",
    name: "YZ Büyüme Tahmini",
    description: "Yapay zeka algoritmaları ile öngörülen büyüme potansiyeli",
    category: 'ai',
    defaultWeight: 65,
  }
];

// Kategorilerin Türkçe karşılıkları
export const categoryLabels = {
  'financial': 'Finansal Göstergeler',
  'technical': 'Teknik Analiz',
  'fundamental': 'Temel Analiz',
  'esg': 'ESG (Çevresel, Sosyal, Yönetişim)',
  'sentiment': 'Piyasa Duyarlılığı',
  'ai': 'Yapay Zeka Analizi'
};

// Analiz sonuçlarını hesaplamak için yardımcı fonksiyon
export function calculateAnalysisScore(
  stockData: any,
  selectedCriteria: SelectedCriterion[]
): number {
  if (!selectedCriteria.length) return 0;
  
  const enabledCriteria = selectedCriteria.filter(c => c.enabled);
  if (!enabledCriteria.length) return 0;
  
  const totalWeight = enabledCriteria.reduce((sum, c) => sum + c.weight, 0);
  
  if (totalWeight === 0) return 0;
  
  const weightedScore = enabledCriteria.reduce((score, criterion) => {
    // Bu kriter için veri varsa puanı hesapla
    const criterionScore = stockData[criterion.id] || 0;
    return score + (criterionScore * criterion.weight);
  }, 0);
  
  return Math.round((weightedScore / totalWeight) * 100) / 100;
}