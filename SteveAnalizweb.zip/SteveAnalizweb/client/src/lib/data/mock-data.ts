import { 
  BarChart3, 
  Coins, 
  Factory, 
  Lightbulb, 
  Users, 
  Leaf, 
  Bot
} from "lucide-react";

// Market indices
export const marketIndices = [
  {
    id: "sp500",
    name: "S&P 500",
    value: 4587.98,
    change: -19.31,
    changePercentage: -0.42
  },
  {
    id: "nasdaq",
    name: "NASDAQ",
    value: 14189.64,
    change: 90.81,
    changePercentage: 0.64
  },
  {
    id: "bist100",
    name: "BIST 100",
    value: 8124.36,
    change: 106.24,
    changePercentage: 1.32
  }
];

// 7-criteria analysis
export const criteria = [
  {
    id: "growthRate",
    title: "Growth Rate",
    description: "Evaluates company's historical and projected growth patterns.",
    weight: 25,
    icon: "growthRate"
  },
  {
    id: "financialHealth",
    title: "Financial Health",
    description: "Analyzes debt levels, liquidity, and overall financial stability.",
    weight: 20,
    icon: "financialHealth"
  },
  {
    id: "industryPosition",
    title: "Industry Position",
    description: "Evaluates competitive advantage and market position strength.",
    weight: 15,
    icon: "industryPosition"
  },
  {
    id: "innovation",
    title: "Innovation",
    description: "Assesses R&D investments and technological advancement.",
    weight: 15,
    icon: "innovation"
  },
  {
    id: "community",
    title: "Community",
    description: "Examines social engagement and brand perception.",
    weight: 10,
    icon: "community"
  },
  {
    id: "esgScore",
    title: "ESG Score",
    description: "Measures environmental, social, and governance factors.",
    weight: 10,
    icon: "esgScore"
  },
  {
    id: "aiSentiment",
    title: "AI Sentiment",
    description: "AI-powered analysis of news and social media sentiment.",
    weight: 5,
    icon: "aiSentiment"
  }
];

// Top stocks
export const topStocks = [
  {
    id: "TSLA",
    symbol: "TSLA",
    name: "Tesla Inc.",
    exchange: "NASDAQ",
    score: 87,
    recommendation: "Strong Buy",
    price: 824.40,
    change: 26.32,
    changePercent: 3.2,
    trend: "M0,10 L5,8 L10,12 L15,10 L20,14 L25,7 L30,12 L35,8 L40,10 L45,5 L50,9"
  },
  {
    id: "NVDA",
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    exchange: "NASDAQ",
    score: 83,
    recommendation: "Strong Buy",
    price: 267.58,
    change: 7.49,
    changePercent: 2.8,
    trend: "M0,15 L5,13 L10,11 L15,12 L20,8 L25,5 L30,7 L35,6 L40,4 L45,5 L50,3"
  },
  {
    id: "AAPL",
    symbol: "AAPL",
    name: "Apple Inc.",
    exchange: "NASDAQ",
    score: 79,
    recommendation: "Buy",
    price: 176.28,
    change: -1.42,
    changePercent: -0.8,
    trend: "M0,10 L5,11 L10,9 L15,10 L20,8 L25,11 L30,10 L35,9 L40,8 L45,9 L50,7"
  },
  {
    id: "META",
    symbol: "META",
    name: "Meta Platforms",
    exchange: "NASDAQ",
    score: 76,
    recommendation: "Buy",
    price: 352.92,
    change: 5.22,
    changePercent: 1.5,
    trend: "M0,15 L5,12 L10,13 L15,10 L20,8 L25,6 L30,7 L35,5 L40,6 L45,4 L50,3"
  },
  {
    id: "MSFT",
    symbol: "MSFT",
    name: "Microsoft Corp.",
    exchange: "NASDAQ",
    score: 75,
    recommendation: "Buy",
    price: 326.80,
    change: -0.65,
    changePercent: -0.2,
    trend: "M0,10 L5,8 L10,9 L15,7 L20,8 L25,6 L30,5 L35,7 L40,6 L45,5 L50,4"
  }
];

// Trending sectors
export const trendingSectors = [
  { name: "Technology", change: "+2.8%" },
  { name: "Healthcare", change: "+1.5%" },
  { name: "Consumer Discretionary", change: "-0.6%" },
  { name: "Financials", change: "+0.3%" }
];

// AI insights
export const aiInsights = [
  { 
    text: "Consider increasing exposure to AI-related tech stocks given recent breakthroughs and adoption trends.", 
    type: "positive" 
  },
  { 
    text: "Healthcare sector shows promise with emerging biotech companies demonstrating strong innovation scores.", 
    type: "positive" 
  },
  { 
    text: "Monitor energy sector closely as renewable companies are gaining momentum.", 
    type: "warning" 
  }
];

// Chart data for market performance
export const chartData = [
  {
    label: "S&P 500",
    data: [
      { x: "Jan", y: 4200 },
      { x: "Feb", y: 4280 },
      { x: "Mar", y: 4150 },
      { x: "Apr", y: 4350 },
      { x: "May", y: 4450 },
      { x: "Jun", y: 4350 },
      { x: "Jul", y: 4580 },
      { x: "Aug", y: 4650 },
      { x: "Sep", y: 4500 },
      { x: "Oct", y: 4550 },
      { x: "Nov", y: 4480 },
      { x: "Dec", y: 4580 }
    ],
    borderColor: "#2563EB",
    backgroundColor: "rgba(37, 99, 235, 0.1)"
  },
  {
    label: "NASDAQ",
    data: [
      { x: "Jan", y: 14000 },
      { x: "Feb", y: 14200 },
      { x: "Mar", y: 13800 },
      { x: "Apr", y: 14500 },
      { x: "May", y: 14700 },
      { x: "Jun", y: 14400 },
      { x: "Jul", y: 14800 },
      { x: "Aug", y: 15200 },
      { x: "Sep", y: 14700 },
      { x: "Oct", y: 14900 },
      { x: "Nov", y: 14600 },
      { x: "Dec", y: 14900 }
    ],
    borderColor: "#10B981",
    backgroundColor: "rgba(16, 185, 129, 0.1)"
  }
];

// Sector allocation data
export const sectorData = [
  { label: "Technology", value: 28, color: "#3B82F6" },
  { label: "Healthcare", value: 18, color: "#10B981" },
  { label: "Financials", value: 16, color: "#F59E0B" },
  { label: "Consumer Discretionary", value: 14, color: "#EF4444" },
  { label: "Communication Services", value: 12, color: "#8B5CF6" },
  { label: "Other", value: 12, color: "#6B7280" }
];

// News items
export const newsItems = [
  {
    id: "news1",
    title: "AI Revolution Continues to Drive Tech Stock Growth",
    description: "Major tech companies investing heavily in artificial intelligence are seeing significant market gains as adoption accelerates across industries.",
    category: "Technology",
    time: "2 hours ago",
    source: "Bloomberg",
    imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80"
  },
  {
    id: "news2",
    title: "Federal Reserve Signals Potential Rate Adjustments",
    description: "In response to changing economic indicators, the Federal Reserve has hinted at upcoming monetary policy adjustments.",
    category: "Finance",
    time: "6 hours ago",
    source: "Reuters",
    imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80"
  },
  {
    id: "news3",
    title: "Biotech Startups Attract Record Venture Capital",
    description: "Innovative biotech companies developing breakthrough treatments are seeing unprecedented levels of investment in the first quarter.",
    category: "Healthcare",
    time: "1 day ago",
    source: "Financial Times",
    imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=300&q=80"
  }
];
