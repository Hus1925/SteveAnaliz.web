import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ArrowDown, ArrowUp } from "lucide-react";
import { useState } from "react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ChartContainer } from "@/components/ui/chart-container";

interface Stock {
  id: string;
  symbol: string;
  name: string;
  exchange: string;
  score: number;
  recommendation: 'Strong Buy' | 'Buy' | 'Hold' | 'Sell' | 'Strong Sell';
  price: number;
  change: number;
  changePercent: number;
  trend: string;
}

interface StockTableProps {
  stocks: Stock[];
  title: string;
  description?: string;
}

export function StockTable({ stocks, title, description }: StockTableProps) {
  const [timeFrame, setTimeFrame] = useState("24h");

  const getRecommendationClass = (recommendation: string) => {
    switch (recommendation) {
      case 'Strong Buy':
      case 'Buy':
        return 'bg-green-100 text-green-800';
      case 'Hold':
        return 'bg-yellow-100 text-yellow-800';
      case 'Sell':
      case 'Strong Sell':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <ChartContainer 
      title={title} 
      description={description}
      headerAction={
        <Select defaultValue={timeFrame} onValueChange={setTimeFrame}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time frame" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="24h">Last 24 hours</SelectItem>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
          </SelectContent>
        </Select>
      }
    >
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[250px]">Company</TableHead>
              <TableHead>Score</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Change</TableHead>
              <TableHead>Trend</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {stocks.map((stock) => (
              <TableRow key={stock.id} className="hover:bg-gray-50 cursor-pointer">
                <TableCell>
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center bg-primary-100 text-primary-800 rounded-full">
                      {stock.symbol}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{stock.name}</div>
                      <div className="text-sm text-gray-500">{stock.exchange}: {stock.symbol}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <span className="text-sm font-medium text-gray-900">{stock.score}</span>
                    <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRecommendationClass(stock.recommendation)}">
                      {stock.recommendation}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-sm text-gray-900">${stock.price.toFixed(2)}</TableCell>
                <TableCell>
                  <span className={`flex items-center ${stock.change >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                    {stock.change >= 0 ? (
                      <ArrowUp className="h-4 w-4 mr-1" />
                    ) : (
                      <ArrowDown className="h-4 w-4 mr-1" />
                    )}
                    {stock.change >= 0 ? '+' : ''}{stock.changePercent.toFixed(1)}%
                  </span>
                </TableCell>
                <TableCell>
                  <div className="w-16 h-8">
                    <svg viewBox="0 0 50 20" className="w-full h-full">
                      <path d={stock.trend} fill="none" stroke={stock.change >= 0 ? "rgb(16, 185, 129)" : "rgb(239, 68, 68)"} strokeWidth="2"></path>
                    </svg>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="link" className="text-primary-600 hover:text-primary-900">
                    View Analysis
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </ChartContainer>
  );
}
