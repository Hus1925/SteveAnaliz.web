import { ReactNode } from "react";

interface DashboardHeaderProps {
  title: string;
  description?: string;
  children?: ReactNode;
}

export function DashboardHeader({ title, description, children }: DashboardHeaderProps) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-bold font-heading text-gray-900">{title}</h1>
      {description && <p className="text-gray-600 mt-1">{description}</p>}
      {children}
    </div>
  );
}
