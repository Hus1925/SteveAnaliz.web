import { useEffect, useRef } from 'react';
import { ChartContainer } from '@/components/ui/chart-container';
import Chart from 'chart.js/auto';

interface SectorData {
  label: string;
  value: number;
  color: string;
}

interface SectorChartProps {
  title: string;
  description?: string;
  data: SectorData[];
}

export function SectorChart({ title, description, data }: SectorChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      // Destroy previous chart instance if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      // Create new chart
      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        chartInstance.current = new Chart(ctx, {
          type: 'doughnut',
          data: {
            labels: data.map(item => item.label),
            datasets: [{
              data: data.map(item => item.value),
              backgroundColor: data.map(item => item.color),
              borderWidth: 0
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'right',
                labels: {
                  usePointStyle: true,
                  boxWidth: 8,
                  padding: 15
                }
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    return `${context.label}: ${context.raw}%`;
                  }
                }
              }
            },
            cutout: '70%'
          }
        });
      }
    }

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data]);

  return (
    <ChartContainer title={title} description={description}>
      <div style={{ height: '300px' }}>
        <canvas ref={chartRef}></canvas>
      </div>
    </ChartContainer>
  );
}
