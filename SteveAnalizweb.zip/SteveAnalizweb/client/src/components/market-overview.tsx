import { MarketIndexCard } from "@/components/ui/market-index-card";

interface MarketIndex {
  id: string;
  name: string;
  value: number;
  change: number;
  changePercentage?: number;  // İsteğe bağlı yapıldı
  changePercent?: number;     // Yeni eklendi - alternatif ad
}

interface MarketOverviewProps {
  indices: MarketIndex[];
}

export function MarketOverview({ indices }: MarketOverviewProps) {
  // changePercent veya changePercentage hangisi varsa onu kullan
  const processedIndices = indices.map(index => ({
    ...index,
    changePercentage: index.changePercentage ?? index.changePercent ?? 0
  }));

  return (
    <div className="mb-6">
      <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-medium leading-6 text-gray-900 dark:text-gray-100">Piyasaya Genel Bakış</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500 dark:text-gray-400">Önemli endeksler ve piyasa göstergeleri</p>
        </div>
        <div className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          {processedIndices.map((index) => (
            <MarketIndexCard
              key={index.id}
              name={index.name}
              value={index.value}
              change={index.change}
              changePercentage={index.changePercentage}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
