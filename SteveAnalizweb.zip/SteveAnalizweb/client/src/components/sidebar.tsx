import { cn } from "@/lib/utils";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  BarChart2,
  Home,
  LineChart,
  List,
  FileText,
  Users,
  Settings,
  HelpCircle,
  SlidersHorizontal,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  const routes = [
    {
      title: "Dashboard",
      label: "",
      icon: Home,
      href: "/",
      variant: "default"
    },
    {
      title: "Analysis",
      label: "",
      icon: LineChart,
      href: "/analysis",
      variant: "default"
    },
    {
      title: "Özel Analiz",
      label: "Yeni",
      icon: SlidersHorizontal,
      href: "/custom-analysis",
      variant: "default"
    },
    {
      title: "Watchlist",
      label: "",
      icon: List,
      href: "/watchlist",
      variant: "default"
    },
    {
      title: "Reports",
      label: "",
      icon: FileText,
      href: "/reports",
      variant: "default"
    },
    {
      title: "Community",
      label: "New",
      icon: Users,
      href: "/community",
      variant: "default"
    }
  ];

  const utilityRoutes = [
    {
      title: "Settings",
      label: "",
      icon: Settings,
      href: "/settings",
      variant: "ghost"
    },
    {
      title: "Help & Support",
      label: "",
      icon: HelpCircle,
      href: "/help",
      variant: "ghost"
    }
  ];

  if (!user) return null;

  return (
    <div className={cn("pb-12 w-[220px] border-r bg-sidebar", className)}>
      <div className="space-y-4 py-4">
        <div className="px-4 py-2">
          <div className="flex flex-col">
            <div className="flex-shrink-0 font-heading font-bold text-xl text-primary-900">
              <span>Steve</span><span className="text-primary-600">Analiz</span><span className="text-xs">.web</span>
            </div>
            <div className="text-xs text-gray-600 font-medium mt-1">
              GELECEĞE YÖNELİK FİNANSAL ANALİZ PLATFORMU
            </div>
          </div>
        </div>
        <div className="px-4 py-2">
          <h2 className="mb-2 px-2 text-sm font-semibold tracking-tight text-sidebar-foreground">
            Main Navigation
          </h2>
          <div className="space-y-1">
            {routes.map((route) => (
              <Link key={route.href} href={route.href}>
                <Button
                  variant={location === route.href ? "secondary" : "ghost"}
                  size="sm"
                  className="w-full justify-start"
                >
                  <route.icon className="mr-2 h-4 w-4" />
                  {route.title}
                  {route.label && (
                    <span className="ml-auto text-xs bg-primary-100 text-primary-800 rounded-full px-2 py-0.5">
                      {route.label}
                    </span>
                  )}
                </Button>
              </Link>
            ))}
          </div>
        </div>
        <div className="px-4 py-2">
          <h2 className="mb-2 px-2 text-sm font-semibold tracking-tight text-sidebar-foreground">
            Utilities
          </h2>
          <div className="space-y-1">
            {utilityRoutes.map((route) => (
              <Link key={route.href} href={route.href}>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start"
                >
                  <route.icon className="mr-2 h-4 w-4" />
                  {route.title}
                  {route.label && (
                    <span className="ml-auto text-xs rounded-full px-2 py-0.5">
                      {route.label}
                    </span>
                  )}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
