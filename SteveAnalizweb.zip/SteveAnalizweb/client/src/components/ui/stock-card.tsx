import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowDown, ArrowUp } from "lucide-react";

interface StockCardProps {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercentage: number;
  className?: string;
}

export function StockCard({
  symbol,
  name,
  price,
  change,
  changePercentage,
  className,
}: StockCardProps) {
  const isPositive = change >= 0;

  return (
    <Card className={cn("hover:shadow-md transition-shadow", className)}>
      <CardContent className="p-4 flex items-center justify-between">
        <div className="flex items-center">
          <div className="h-10 w-10 flex items-center justify-center bg-primary-100 text-primary-800 rounded-full text-sm font-semibold">
            {symbol}
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">{name}</div>
            <div className="text-sm text-gray-500">{symbol}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm font-semibold">${price.toFixed(2)}</div>
          <div className={cn(
            "text-xs flex items-center justify-end",
            isPositive ? "text-green-600" : "text-red-500"
          )}>
            {isPositive ? (
              <ArrowUp className="h-3 w-3 mr-1" />
            ) : (
              <ArrowDown className="h-3 w-3 mr-1" />
            )}
            {isPositive ? '+' : ''}{change.toFixed(2)} ({isPositive ? '+' : ''}{changePercentage.toFixed(2)}%)
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
