import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowDown, ArrowUp } from "lucide-react";

interface MarketIndexCardProps {
  name: string;
  value: number;
  change: number;
  changePercentage: number;
  className?: string;
}

export function MarketIndexCard({
  name,
  value,
  change,
  changePercentage,
  className
}: MarketIndexCardProps) {
  const isPositive = changePercentage >= 0;

  return (
    <Card className={cn("bg-gray-50", className)}>
      <CardContent className="p-4 flex items-center">
        <div className="mr-4">
          <div className="text-sm font-medium text-gray-500">{name}</div>
          <div className="text-2xl font-bold">{value.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
        </div>
        <div className="flex flex-col items-end ml-auto">
          <div className={cn(
            "flex items-center",
            isPositive ? "text-green-500" : "text-red-500"
          )}>
            <span>{isPositive ? '+' : ''}{changePercentage.toFixed(2)}%</span>
            {isPositive ? (
              <ArrowUp className="h-4 w-4 ml-1" />
            ) : (
              <ArrowDown className="h-4 w-4 ml-1" />
            )}
          </div>
          <div className="text-xs text-gray-500">Today</div>
        </div>
      </CardContent>
    </Card>
  );
}
