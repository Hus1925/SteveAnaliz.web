import * as React from "react";
import { cn } from "@/lib/utils";
import { Slider } from "@/components/ui/slider";

interface InteractiveSliderProps {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
  className?: string;
  disabled?: boolean;
  showValueBubble?: boolean;
  showMarks?: boolean;
  marksCount?: number;
  markLabelInterval?: number;
  touchFeedback?: boolean;
}

export const InteractiveSlider = React.forwardRef<HTMLDivElement, InteractiveSliderProps>(
  ({ 
    value, 
    min = 0, 
    max = 100, 
    step = 1, 
    onChange, 
    className, 
    disabled = false,
    showValueBubble = true,
    showMarks = true,
    marksCount = 5,
    markLabelInterval = 1,
    touchFeedback = true
  }, ref) => {
    const [isDragging, setIsDragging] = React.useState(false);
    const [lastTouched, setLastTouched] = React.useState(-1);
    const sliderRef = React.useRef<HTMLDivElement>(null);
    const [touchRipples, setTouchRipples] = React.useState<Array<{id: number, x: number, y: number, opacity: number}>>([]);
    
    // Ölçeklendirilmiş değer hesaplama (0-100 arasında)
    const normalizedValue = ((value - min) / (max - min)) * 100;
    
    // İşaretleyiciler için pozisyonlar oluşturma
    const marks = React.useMemo(() => {
      let result = [];
      for (let i = 0; i < marksCount; i++) {
        const markValue = min + (i / (marksCount - 1)) * (max - min);
        const shouldLabel = i % markLabelInterval === 0;
        result.push({
          value: markValue,
          position: (i / (marksCount - 1)) * 100,
          label: shouldLabel ? markValue.toString() : null
        });
      }
      return result;
    }, [min, max, marksCount, markLabelInterval]);
    
    // Fare/dokunma konumunu değere dönüştürme
    const getValueFromPosition = (clientX: number) => {
      if (!sliderRef.current) return value;
      
      const rect = sliderRef.current.getBoundingClientRect();
      const position = (clientX - rect.left) / rect.width;
      const newValue = min + position * (max - min);
      
      // Adıma göre yuvarlama
      return Math.round(newValue / step) * step;
    };
    
    // Dokunma efekti oluşturma
    const createTouchRipple = (clientX: number, clientY: number) => {
      if (!touchFeedback || !sliderRef.current) return;
      
      const rect = sliderRef.current.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;
      
      const id = Date.now();
      setTouchRipples(prev => [...prev, { id, x, y, opacity: 1 }]);
      
      // Zamanla kaybolma efekti
      setTimeout(() => {
        setTouchRipples(prev => prev.filter(r => r.id !== id));
      }, 600);
    };
    
    // Fare/dokunma olayları
    const handlePointerDown = (e: React.PointerEvent) => {
      if (disabled) return;
      
      setIsDragging(true);
      const newValue = getValueFromPosition(e.clientX);
      setLastTouched(normalizedValue);
      createTouchRipple(e.clientX, e.clientY);
      onChange(newValue);
      
      // Küresel olayları dinleme
      document.addEventListener('pointermove', handlePointerMove);
      document.addEventListener('pointerup', handlePointerUp);
    };
    
    const handlePointerMove = (e: PointerEvent) => {
      if (!isDragging || disabled) return;
      
      const newValue = getValueFromPosition(e.clientX);
      onChange(newValue);
    };
    
    const handlePointerUp = () => {
      setIsDragging(false);
      
      // Küresel olay dinleyicilerini kaldırma
      document.removeEventListener('pointermove', handlePointerMove);
      document.removeEventListener('pointerup', handlePointerUp);
    };
    
    // Temizlik
    React.useEffect(() => {
      return () => {
        document.removeEventListener('pointermove', handlePointerMove);
        document.removeEventListener('pointerup', handlePointerUp);
      };
    }, []);
    
    return (
      <div 
        ref={ref} 
        className={cn(
          "relative py-5", 
          disabled && "opacity-60 cursor-not-allowed",
          className
        )}
      >
        {/* Ana Slider bileşeni */}
        <div 
          ref={sliderRef}
          className="relative h-7 touch-none"
          onPointerDown={handlePointerDown}
        >
          {/* Temel izleyici */}
          <div className="absolute h-2 top-2.5 w-full bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
            {/* Doldurulmuş kısım */}
            <div 
              className={cn(
                "absolute h-full bg-primary transition-all", 
                isDragging && "bg-primary-600"
              )} 
              style={{ width: `${normalizedValue}%` }}
            />
          </div>
          
          {/* İşaretleyiciler */}
          {showMarks && marks.map((mark, i) => (
            <div key={i} className="contents">
              <div 
                className={cn(
                  "absolute top-2.5 h-2 w-0.5 -ml-0.5 pointer-events-none",
                  mark.value <= value ? "bg-primary-600" : "bg-gray-400 dark:bg-gray-600"
                )}
                style={{ left: `${mark.position}%` }}
              />
              {mark.label && (
                <div 
                  className="absolute text-[10px] text-gray-500 dark:text-gray-400 mt-2.5 -ml-3"
                  style={{ left: `${mark.position}%`, top: "100%" }}
                >
                  {mark.label}
                </div>
              )}
            </div>
          ))}
          
          {/* Kaydırma noktası */}
          <div 
            className={cn(
              "absolute top-1 h-5 w-5 rounded-full border-2 border-primary bg-background -ml-2.5 transition-all",
              "shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
              isDragging && "scale-110 border-primary-600 shadow-lg dark:shadow-primary-900/20", 
              disabled && "opacity-50"
            )}
            style={{ left: `${normalizedValue}%` }}
          />
          
          {/* Dokunma dalgaları */}
          {touchRipples.map(ripple => (
            <div
              key={ripple.id}
              className="absolute w-8 h-8 rounded-full bg-primary opacity-20 pointer-events-none transition-all -ml-4 -mt-4"
              style={{
                left: ripple.x,
                top: ripple.y,
                transform: 'scale(1.5)',
                opacity: ripple.opacity,
                transition: 'opacity 0.6s ease-out, transform 0.6s ease-out'
              }}
            />
          ))}
        </div>
        
        {/* Değer balonu */}
        {showValueBubble && (
          <div 
            className={cn(
              "absolute -top-8 px-2 py-1 text-xs font-semibold bg-primary text-white rounded transition-all transform -translate-x-1/2",
              isDragging ? "opacity-100 scale-100" : "opacity-0 scale-90"
            )}
            style={{ left: `${normalizedValue}%` }}
          >
            {value.toFixed(step < 1 ? 1 : 0)}
          </div>
        )}
      </div>
    );
  }
);

InteractiveSlider.displayName = "InteractiveSlider";