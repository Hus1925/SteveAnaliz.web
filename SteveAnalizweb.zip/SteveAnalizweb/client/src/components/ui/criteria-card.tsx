import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { ReactNode } from "react";

interface CriteriaCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  weight: number;
  className?: string;
}

export function CriteriaCard({
  icon,
  title,
  description,
  weight,
  className
}: CriteriaCardProps) {
  return (
    <Card className={cn(
      "bg-primary-50 border border-primary-100 hover:border-primary-300 transition-all hover:-translate-y-1 cursor-pointer",
      className
    )}>
      <CardContent className="p-4">
        <div className="flex items-center mb-3">
          <div className="bg-primary-100 rounded-full p-2 mr-3 text-primary-700">
            {icon}
          </div>
          <h4 className="font-medium text-primary-900">{title}</h4>
        </div>
        <p className="text-sm text-gray-600">{description}</p>
        <div className="mt-2 text-xs text-right">
          <span className="text-primary-700 font-medium">Weight: {weight}%</span>
        </div>
      </CardContent>
    </Card>
  );
}
