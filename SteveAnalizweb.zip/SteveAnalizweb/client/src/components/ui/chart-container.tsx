import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface ChartContainerProps {
  title: string;
  description?: string;
  children: ReactNode;
  className?: string;
  headerAction?: ReactNode;
}

export function ChartContainer({
  title,
  description,
  children,
  className,
  headerAction
}: ChartContainerProps) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="px-4 py-5 sm:px-6 border-b bg-white">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-medium leading-6 text-gray-900">{title}</CardTitle>
            {description && <CardDescription className="mt-1 max-w-2xl text-sm text-gray-500">{description}</CardDescription>}
          </div>
          {headerAction && (
            <div>
              {headerAction}
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-4 md:p-6">
        {children}
      </CardContent>
    </Card>
  );
}
