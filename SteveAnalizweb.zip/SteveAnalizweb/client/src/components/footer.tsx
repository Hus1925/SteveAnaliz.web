import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex-shrink-0 font-heading font-bold text-2xl text-primary-900 mb-4">
              <span>Steve</span><span className="text-primary-600">Analiz</span><span className="text-xs">.web</span>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Empowering individual investors with advanced financial analysis tools and market insights.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-primary-600">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary-600">
                <i className="fab fa-linkedin"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary-600">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary-600">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900 uppercase tracking-wider mb-4">Platform</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-gray-600 hover:text-primary-600 text-sm">Dashboard</Link>
              </li>
              <li>
                <Link href="/analysis" className="text-gray-600 hover:text-primary-600 text-sm">Stock Analysis</Link>
              </li>
              <li>
                <Link href="/reports" className="text-gray-600 hover:text-primary-600 text-sm">Custom Reports</Link>
              </li>
              <li>
                <Link href="/watchlist" className="text-gray-600 hover:text-primary-600 text-sm">Watchlists</Link>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">AI Insights</a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900 uppercase tracking-wider mb-4">Resources</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Learning Center</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Knowledge Base</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Community Forum</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">API Documentation</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Support Center</a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900 uppercase tracking-wider mb-4">Company</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">About Us</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Careers</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Press</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Contact</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-primary-600 text-sm">Privacy Policy</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-200 md:flex md:items-center md:justify-between">
          <p className="text-sm text-gray-500">&copy; 2023 SteveAnaliz.web. All rights reserved.</p>
          <div className="mt-4 md:mt-0">
            <div className="flex space-x-6">
              <a href="#" className="text-xs text-gray-600 hover:text-primary-600">Terms of Service</a>
              <a href="#" className="text-xs text-gray-600 hover:text-primary-600">Privacy Policy</a>
              <a href="#" className="text-xs text-gray-600 hover:text-primary-600">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
