import { CriteriaCard } from "@/components/ui/criteria-card";
import { BarChart3, Coins, Factory, Lightbulb, Users, Leaf, Bot } from "lucide-react";

interface Criterion {
  id: string;
  title: string;
  description: string;
  weight: number;
  icon: keyof typeof icons;
}

const icons = {
  growthRate: <BarChart3 className="h-4 w-4" />,
  financialHealth: <Coins className="h-4 w-4" />,
  industryPosition: <Factory className="h-4 w-4" />,
  innovation: <Lightbulb className="h-4 w-4" />,
  community: <Users className="h-4 w-4" />,
  esgScore: <Leaf className="h-4 w-4" />,
  aiSentiment: <Bot className="h-4 w-4" />,
};

interface AnalysisCriteriaProps {
  criteria: Criterion[];
}

export function AnalysisCriteria({ criteria }: AnalysisCriteriaProps) {
  return (
    <div className="mb-8">
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium leading-6 text-gray-900">7 Key Analysis Criteria</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Our assessment methodology for identifying potential opportunities</p>
        </div>
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 overflow-x-auto scrollbar-hide">
          {criteria.map((criterion) => (
            <CriteriaCard
              key={criterion.id}
              icon={icons[criterion.icon as keyof typeof icons]}
              title={criterion.title}
              description={criterion.description}
              weight={criterion.weight}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
