import { Button } from "@/components/ui/button";

export function CtaSection() {
  return (
    <div className="bg-primary-800 text-white shadow rounded-lg overflow-hidden mb-8">
      <div className="max-w-7xl mx-auto px-6 py-12 md:flex md:items-center md:justify-between">
        <div className="max-w-3xl mb-6 md:mb-0">
          <h2 className="text-2xl font-bold font-heading">Ready to elevate your investment strategy?</h2>
          <p className="mt-2 text-primary-200">
            Upgrade to SteveAnaliz.web Pro for advanced analysis features, real-time alerts, and premium market insights.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button className="bg-white text-primary-800 hover:bg-primary-50 transition-colors">
            Explore Pro Features
          </Button>
          <Button variant="outline" className="border-primary-300 text-white hover:bg-primary-700">
            Schedule Demo
          </Button>
        </div>
      </div>
    </div>
  );
}
