// Ticker öğesi için prop tipi tanımlıyoruz
interface TickerItemProps {
  name: string;
  value: number;
  change: number;
  changePercent: number;
  symbol?: string;
  currency?: string;
  type?: "stock" | "crypto" | "commodity" | "index";
}
import { cn, formatCurrency, formatPercentage } from "@/lib/utils";
import { useEffect, useRef } from "react";

interface MarketTickerSliderProps {
  title: string;
  items: TickerItemProps[];
}

export function MarketTickerSlider({ title, items }: MarketTickerSliderProps) {
  const marqueeRef = useRef<HTMLDivElement>(null);
  
  // Duplicate items to ensure smooth looping
  const loopedItems = [...items, ...items];
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <div className="p-3 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
        <h3 className="text-sm font-medium flex items-center">
          {title}
        </h3>
        <div className="text-xs text-gray-500 dark:text-gray-400 flex items-center">
          <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></div>
          Canlı Veri
        </div>
      </div>
      
      <div className="overflow-hidden">
        <div
          ref={marqueeRef}
          className="animate-marquee whitespace-nowrap flex space-x-4 py-3 px-4"
        >
          {loopedItems.map((item, idx) => (
            <TickerSliderItem key={`${item.symbol || item.name}-${idx}`} item={item} />
          ))}
        </div>
      </div>
    </div>
  );
}

function TickerSliderItem({ item }: { item: TickerItemProps }) {
  const isPositive = item.changePercent >= 0;
  
  return (
    <div className="inline-flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-800 transition-colors hover:bg-gray-100 dark:hover:bg-gray-800/80">
      <div className="mr-3">
        <div className="font-medium text-sm">{item.name}</div>
        <div className="text-xs text-gray-500 dark:text-gray-400">{item.symbol || ""}</div>
      </div>
      <div className="text-right">
        <div className="font-medium text-sm">{formatCurrency(item.value, item.currency || "USD")}</div>
        <div className={`text-xs flex items-center ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
          {isPositive ? '▲' : '▼'} {formatPercentage(item.changePercent)}
        </div>
      </div>
    </div>
  );
}