import { Button } from "@/components/ui/button";
import { NewsCard } from "@/components/news-card";

interface NewsItem {
  id: string;
  title: string;
  description: string;
  category: string;
  time: string;
  source: string;
  imageUrl: string;
}

interface NewsSectionProps {
  newsItems: NewsItem[];
}

export function NewsSection({ newsItems }: NewsSectionProps) {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden mb-8">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-medium leading-6 text-gray-900">Latest Financial News</h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">Stay updated with market developments</p>
          </div>
          <Button variant="link" className="text-primary-600 hover:text-primary-800">
            View All <i className="fas fa-arrow-right ml-1"></i>
          </Button>
        </div>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {newsItems.map((item) => (
            <NewsCard
              key={item.id}
              title={item.title}
              description={item.description}
              category={item.category}
              time={item.time}
              source={item.source}
              imageUrl={item.imageUrl}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
