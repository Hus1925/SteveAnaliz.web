import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { formatCurrency as formatCurrencyUtil, formatPercentage } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

// Ticker öğesi için prop tipi
interface TickerItemProps {
  name: string;
  value: number;
  change: number;
  changePercent: number;
  symbol?: string;
  currency?: string;
  type?: "stock" | "crypto" | "commodity" | "index";
}

// Ticker kategorisi
interface TickerCategoryProps {
  title: string;
  items: TickerItemProps[];
}

// Bireysel ticker öğesi
export function TickerItem({ name, value, change, changePercent, symbol, currency = "USD", type = "stock" }: TickerItemProps) {
  const isPositive = changePercent >= 0;

  return (
    <div className="flex items-center justify-between px-4 py-2 whitespace-nowrap">
      <div className="flex items-center">
        <div className={cn(
          "w-2 h-2 rounded-full mr-2",
          type === "stock" ? "bg-blue-500" : 
          type === "crypto" ? "bg-purple-500" : 
          type === "commodity" ? "bg-amber-500" : 
          "bg-green-500"
        )}></div>
        <span className="font-medium">{symbol ? `${symbol} - ` : ""}{name}</span>
      </div>
      <div className="flex items-center">
        <span className="text-gray-900 dark:text-gray-100 font-medium mr-3">
          {formatCurrencyUtil(value, currency)}
        </span>
        <div className={cn(
          "flex items-center",
          isPositive ? "text-green-600" : "text-red-600"
        )}>
          {isPositive ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
          <span>{formatPercentage(changePercent)}</span>
        </div>
      </div>
    </div>
  );
}

// Sürekli akan ticker
export function MarketTicker({ categories }: { categories: TickerCategoryProps[] }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(true);

  // Yeni ticker bloğuna geçiş
  useEffect(() => {
    const interval = setInterval(() => {
      if (isAnimating) {
        setActiveIndex((current) => (current + 1) % categories.length);
      }
    }, 10000); // 10 saniye aralıklarla değiştir

    return () => clearInterval(interval);
  }, [categories.length, isAnimating]);

  return (
    <div className="w-full overflow-hidden bg-gray-50 dark:bg-gray-900 border rounded-lg">
      <div className="flex justify-between items-center px-4 py-2 bg-gray-100 dark:bg-gray-800 border-b">
        <h3 className="font-semibold text-sm">{categories[activeIndex].title}</h3>
        <div className="flex space-x-2">
          {categories.map((_, index) => (
            <button 
              key={index}
              onClick={() => {
                setActiveIndex(index);
                setIsAnimating(false);
                setTimeout(() => setIsAnimating(true), 30000); // 30 saniye duraksatır
              }}
              className={cn(
                "w-2 h-2 rounded-full transition-colors",
                index === activeIndex ? "bg-primary" : "bg-gray-300 dark:bg-gray-600"
              )}
            />
          ))}
          <button 
            onClick={() => setIsAnimating(!isAnimating)}
            className="text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 ml-2"
          >
            {isAnimating ? "Durdur" : "Devam Et"}
          </button>
        </div>
      </div>
      
      <div className="overflow-hidden relative">
        <div className="flex overflow-x-auto scrollbar-hide">
          {categories[activeIndex].items.map((item, index) => (
            <div key={index} className="min-w-[250px] border-r last:border-r-0">
              <TickerItem {...item} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Sürekli akan yatay bilgi bandı
export function ContinuousTicker({ items }: { items: TickerItemProps[] }) {
  const [position, setPosition] = useState(0);

  useEffect(() => {
    const animationFrame = requestAnimationFrame(function animate() {
      setPosition((prev) => (prev - 0.5) % (items.length * 250)); // Smooth animation
      requestAnimationFrame(animate);
    });

    return () => cancelAnimationFrame(animationFrame);
  }, [items.length]);

  return (
    <div className="w-full overflow-hidden bg-primary-900 text-white py-1">
      <div 
        className="flex whitespace-nowrap"
        style={{ transform: `translateX(${position}px)` }}
      >
        {/* İçeriği iki kez ekliyoruz ki akış sorunsuz olsun */}
        {[...items, ...items].map((item, index) => (
          <div key={index} className="inline-flex items-center mx-4">
            <span className="font-medium mr-2">{item.symbol || item.name}</span>
            <span className={cn(
              item.changePercent >= 0 ? "text-green-400" : "text-red-400"
            )}>
              {formatPercentage(item.changePercent)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}