import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusIcon, SlidersHorizontal, Users } from "lucide-react";
import { Link } from "wouter";

export function ActionCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <Card className="bg-primary-700 text-white shadow rounded-lg overflow-hidden flex flex-col">
        <CardHeader className="border-b border-primary-600 px-4 py-5 sm:px-6">
          <CardTitle className="text-lg font-medium leading-6 text-white">Create Watchlist</CardTitle>
          <CardDescription className="text-primary-200">Track your favorite stocks</CardDescription>
        </CardHeader>
        <CardContent className="p-6 flex-grow flex flex-col justify-between">
          <p className="text-primary-100 mb-6">
            Build personalized watchlists to monitor potential investments and stay updated on price movements.
          </p>
          <Link href="/watchlist">
            <Button className="bg-white text-primary-800 hover:bg-primary-50 transition-colors">
              <PlusIcon className="mr-2 h-4 w-4" /> Create New
            </Button>
          </Link>
        </CardContent>
      </Card>
      
      <Card className="bg-gradient-to-br from-primary-800 to-primary-600 text-white shadow rounded-lg overflow-hidden flex flex-col">
        <CardHeader className="border-b border-primary-600 px-4 py-5 sm:px-6">
          <CardTitle className="text-lg font-medium leading-6 text-white">Run Custom Analysis</CardTitle>
          <CardDescription className="text-primary-200">Define your own criteria</CardDescription>
        </CardHeader>
        <CardContent className="p-6 flex-grow flex flex-col justify-between">
          <p className="text-primary-100 mb-6">
            Create custom analyses by adjusting the weights of our 7 key criteria to match your investment strategy.
          </p>
          <Link href="/analysis">
            <Button className="bg-white text-primary-800 hover:bg-primary-50 transition-colors">
              <SlidersHorizontal className="mr-2 h-4 w-4" /> Configure Analysis
            </Button>
          </Link>
        </CardContent>
      </Card>
      
      <Card className="bg-white shadow rounded-lg overflow-hidden flex flex-col">
        <CardHeader className="border-b border-gray-200 px-4 py-5 sm:px-6">
          <CardTitle className="text-lg font-medium leading-6 text-gray-900">Community Insights</CardTitle>
          <CardDescription className="text-gray-500">Connect with other investors</CardDescription>
        </CardHeader>
        <CardContent className="p-6 flex-grow flex flex-col justify-between">
          <p className="text-gray-600 mb-6">
            Join discussions, share insights, and learn from other investors' experiences and strategies.
          </p>
          <Link href="/community">
            <Button className="bg-primary-600 text-white hover:bg-primary-700 transition-colors">
              <Users className="mr-2 h-4 w-4" /> Join Community
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
