import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface NewsCardProps {
  title: string;
  description: string;
  category: string;
  time: string;
  source: string;
  imageUrl: string;
  className?: string;
}

export function NewsCard({
  title,
  description,
  category,
  time,
  source,
  imageUrl,
  className
}: NewsCardProps) {
  return (
    <Card className={cn("overflow-hidden hover:shadow-md transition-shadow", className)}>
      <div className="h-40 bg-gray-200 relative">
        <img src={imageUrl} alt={title} className="w-full h-full object-cover" />
        <div className="absolute top-2 left-2 bg-primary-600 text-white px-2 py-1 rounded text-xs font-medium">
          {category}
        </div>
      </div>
      <CardContent className="p-4">
        <h4 className="font-medium text-gray-900 mb-2">{title}</h4>
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{description}</p>
        <div className="flex justify-between items-center text-xs text-gray-500">
          <span>{time}</span>
          <span>{source}</span>
        </div>
      </CardContent>
    </Card>
  );
}
