import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { ChartContainer } from '@/components/ui/chart-container';
import { Card } from '@/components/ui/card';
import Chart from 'chart.js/auto';

interface DataPoint {
  x: string;
  y: number;
}

interface DataSet {
  label: string;
  data: DataPoint[];
  borderColor: string;
  backgroundColor: string;
}

interface MarketChartProps {
  title: string;
  description?: string;
  datasets: DataSet[];
}

export function MarketChart({ title, description, datasets }: MarketChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const [timeframe, setTimeframe] = useState('1D');
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      // Destroy previous chart instance if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      // Create new chart
      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        chartInstance.current = new Chart(ctx, {
          type: 'line',
          data: {
            datasets: datasets.map(ds => ({
              label: ds.label,
              data: ds.data.map(d => ({ x: d.x, y: d.y })),
              borderColor: ds.borderColor,
              backgroundColor: ds.backgroundColor,
              fill: true,
              tension: 0.4
            }))
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
              mode: 'index',
              intersect: false,
            },
            plugins: {
              legend: {
                position: 'top',
                labels: {
                  usePointStyle: true,
                  boxWidth: 8
                }
              },
              tooltip: {
                usePointStyle: true
              }
            },
            scales: {
              y: {
                grid: {
                  drawBorder: false,
                  color: 'rgba(0, 0, 0, 0.05)',
                },
                ticks: {
                  callback: function(value) {
                    return value.toLocaleString();
                  }
                }
              },
              x: {
                grid: {
                  display: false
                }
              }
            }
          }
        });
      }
    }

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [datasets, timeframe]);

  const timeframeButtons = [
    { label: '1D', value: '1D' },
    { label: '1W', value: '1W' },
    { label: '1M', value: '1M' },
    { label: '1Y', value: '1Y' },
    { label: 'All', value: 'ALL' },
  ];

  return (
    <ChartContainer
      title={title}
      description={description}
      headerAction={
        <div className="flex space-x-2">
          {timeframeButtons.map(button => (
            <Button
              key={button.value}
              variant={timeframe === button.value ? "secondary" : "outline"}
              size="sm"
              onClick={() => setTimeframe(button.value)}
            >
              {button.label}
            </Button>
          ))}
        </div>
      }
    >
      <div style={{ height: '300px' }}>
        <canvas ref={chartRef}></canvas>
      </div>
    </ChartContainer>
  );
}
