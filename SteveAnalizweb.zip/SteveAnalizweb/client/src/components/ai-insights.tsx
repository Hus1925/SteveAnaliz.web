import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface Sector {
  name: string;
  change: string;
}

interface AiInsight {
  text: string;
  type: 'positive' | 'neutral' | 'warning';
}

interface AiInsightsProps {
  sentimentScore: number;
  trendingSectors: Sector[];
  insights: AiInsight[];
}

export function AiInsights({ sentimentScore, trendingSectors, insights }: AiInsightsProps) {
  // Helper function to get the icon for insight type
  const getInsightIcon = (type: 'positive' | 'neutral' | 'warning') => {
    switch (type) {
      case 'positive':
        return <i className="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>;
      case 'warning':
        return <i className="fas fa-exclamation-circle text-amber-500 mt-0.5 mr-2"></i>;
      default:
        return <i className="fas fa-info-circle text-blue-500 mt-0.5 mr-2"></i>;
    }
  };

  return (
    <div className="w-full bg-white shadow rounded-lg overflow-hidden">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <h3 className="text-lg font-medium leading-6 text-gray-900">AI-Powered Insights</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">Market analysis and predictions</p>
      </div>
      <div className="p-4">
        <div className="space-y-4">
          {/* Market Sentiment Card */}
          <Card className="p-4 border rounded-lg bg-gray-50">
            <div className="flex items-center mb-2">
              <div className="h-8 w-8 rounded-full bg-primary-600 flex items-center justify-center text-white mr-3">
                <i className="fas fa-robot"></i>
              </div>
              <h4 className="font-medium text-gray-900">Market Sentiment</h4>
            </div>
            <div className="mb-2">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-gray-600">Bearish</span>
                <span className="text-xs text-gray-600">Bullish</span>
              </div>
              <Progress value={sentimentScore} className="h-2.5 bg-gray-200" />
            </div>
            <p className="text-sm text-gray-600">
              Our AI analysis indicates a {sentimentScore < 40 ? 'bearish' : sentimentScore < 60 ? 'neutral' : 'bullish'} market sentiment based on news, social media, and trading patterns.
            </p>
          </Card>
          
          {/* Trending Sectors Card */}
          <Card className="p-4 border rounded-lg bg-gray-50">
            <div className="flex items-center mb-2">
              <div className="h-8 w-8 rounded-full bg-primary-600 flex items-center justify-center text-white mr-3">
                <i className="fas fa-chart-line"></i>
              </div>
              <h4 className="font-medium text-gray-900">Trending Sectors</h4>
            </div>
            <div className="space-y-2">
              {trendingSectors.map((sector, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm text-gray-700">{sector.name}</span>
                  <span className={`text-xs ${
                    sector.change.startsWith('+') ? 'text-green-600' : 'text-red-500'
                  }`}>{sector.change}</span>
                </div>
              ))}
            </div>
          </Card>
          
          {/* AI Recommendations Card */}
          <Card className="p-4 border rounded-lg bg-gray-50">
            <div className="flex items-center mb-2">
              <div className="h-8 w-8 rounded-full bg-primary-600 flex items-center justify-center text-white mr-3">
                <i className="fas fa-lightbulb"></i>
              </div>
              <h4 className="font-medium text-gray-900">AI Recommendations</h4>
            </div>
            <ul className="space-y-2 text-sm text-gray-600">
              {insights.map((insight, index) => (
                <li key={index} className="flex items-start">
                  {getInsightIcon(insight.type)}
                  <span>{insight.text}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
        
        <div className="mt-4 text-center">
          <button className="text-primary-600 font-medium hover:text-primary-800">
            View Full AI Report <i className="fas fa-arrow-right ml-1"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
