import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { ToggleTheme } from "@/components/toggle-theme";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Search, Menu } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function Header() {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const routes = [
    { path: "/", label: "Dashboard" },
    { path: "/analysis", label: "Analysis" },
    { path: "/watchlist", label: "Watchlist" },
    { path: "/reports", label: "Reports" },
    { path: "/community", label: "Community" },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Get the initials for avatar
  const getInitials = () => {
    if (user?.name) {
      const nameParts = user.name.split(' ');
      if (nameParts.length > 1) {
        return (nameParts[0][0] + nameParts[1][0]).toUpperCase();
      }
      return user.name[0].toUpperCase();
    }
    return user?.username[0].toUpperCase() || 'U';
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <div className="flex flex-col">
            <div className="flex-shrink-0 font-heading font-bold text-2xl text-primary-900">
              <span>Steve</span><span className="text-primary-600">Analiz</span><span className="text-xs">.web</span>
            </div>
            <div className="text-xs text-gray-600 font-medium">
              GELECEĞE YÖNELİK FİNANSAL ANALİZ PLATFORMU
            </div>
          </div>
          <nav className="hidden md:ml-10 md:flex md:space-x-8">
            {routes.map((route) => (
              <Link 
                key={route.path} 
                href={route.path}
                className={`${
                  location === route.path 
                    ? "text-primary-900 font-medium border-b-2 border-primary-600" 
                    : "text-gray-600 hover:text-primary-900"
                } px-1 py-2`}
              >
                {route.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input 
              type="text" 
              placeholder="Search stocks..." 
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          
          <ToggleTheme />
          
          {user && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="p-0">
                  <div className="flex items-center">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>{getInitials()}</AvatarFallback>
                    </Avatar>
                    <span className="ml-2 text-sm font-medium hidden md:block">{user.name || user.username}</span>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={handleLogout}>
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            <Menu className="h-6 w-6" />
          </Button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200 px-2 pt-2 pb-3 space-y-1">
          {routes.map((route) => (
            <Link 
              key={route.path} 
              href={route.path}
              className={`${
                location === route.path 
                  ? "bg-primary-50 border-l-4 border-primary-600 text-primary-900" 
                  : "border-l-4 border-transparent hover:bg-gray-50 hover:border-gray-300 text-gray-600"
              } block px-3 py-2 text-base font-medium`}
              onClick={() => setMobileMenuOpen(false)}
            >
              {route.label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
}
